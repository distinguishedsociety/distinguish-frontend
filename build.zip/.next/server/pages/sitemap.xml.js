"use strict";
(() => {
var exports = {};
exports.id = 164;
exports.ids = [164];
exports.modules = {

/***/ 2463:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var glob__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4230);
/* harmony import */ var glob__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(glob__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_userServices__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7890);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_userServices__WEBPACK_IMPORTED_MODULE_2__]);
_services_userServices__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Sitemap = ()=>{
    return null;
};
const getServerSideProps = async ({ res  })=>{
    var ref;
    const BASE_URL = "https://www.thedistinguishedsociety.com";
    const pagesDir = "pages/**/*.jsx";
    let pagesPaths = await glob__WEBPACK_IMPORTED_MODULE_1__.sync(pagesDir);
    console.log("pages path", pagesPaths);
    pagesPaths = pagesPaths.filter((path)=>!path.includes("[")
    ).filter((path)=>!path.includes("/_")
    ).filter((path)=>!path.includes("404")
    );
    const staticPaths = [
        "https://www.thedistinguishedsociety.com/blogs",
        "https://www.thedistinguishedsociety.com/contactUs",
        "https://www.thedistinguishedsociety.com/privacyPolicy",
        "https://www.thedistinguishedsociety.com/products",
        "https://www.thedistinguishedsociety.com/shippingAndReturn",
        "https://www.thedistinguishedsociety.com/termsAndConditions", 
    ];
    const products = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_2__/* .getAllProducts */ .Dg)(); // some remote API call maybe!
    const dynamicPaths = (ref = products.products) === null || ref === void 0 ? void 0 : ref.map((singleProduct)=>{
        return `${BASE_URL}/products/${singleProduct.slug}`;
    });
    const allPaths = [
        ...staticPaths,
        ...dynamicPaths
    ];
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
      ${allPaths.map((url)=>{
        return `
            <url>
              <loc>${url}</loc>
              <lastmod>${new Date().toISOString()}</lastmod>
              <changefreq>monthly</changefreq>
              <priority>1.0</priority>
            </url>
          `;
    }).join("")}
    </urlset>
  `;
    res.setHeader("Content-Type", "text/xml");
    res.write(sitemap);
    res.end();
    return {
        props: {}
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sitemap);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 4230:
/***/ ((module) => {

module.exports = require("glob");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [890], () => (__webpack_exec__(2463)));
module.exports = __webpack_exports__;

})();