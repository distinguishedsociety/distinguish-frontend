"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405,229];
exports.modules = {

/***/ 4369:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pages_home__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2281);
/* harmony import */ var _services_userServices__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7890);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _context_user__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9568);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_home__WEBPACK_IMPORTED_MODULE_2__, _services_userServices__WEBPACK_IMPORTED_MODULE_3__, _context_user__WEBPACK_IMPORTED_MODULE_5__]);
([_pages_home__WEBPACK_IMPORTED_MODULE_2__, _services_userServices__WEBPACK_IMPORTED_MODULE_3__, _context_user__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

// import  { NextPage } from 'next';





// add bootstrap css 

const Home = ({ products , introBanner , blogs , banners  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_home__WEBPACK_IMPORTED_MODULE_2__["default"], {
        products: products,
        introBanner: introBanner,
        blogs: blogs,
        banners: banners
    });
};
async function getStaticProps() {
    try {
        const { products , errorsProducts  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_3__/* .getAllProducts */ .Dg)();
        const { introBanner , errorsIntroBanner  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_3__/* .getIntroBanner */ .zG)();
        const { banners , errorsBanners  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_3__/* .getBanners */ .Ey)();
        const { blogs , errorsBlogs  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_3__/* .getAllBlogs */ .L)();
        if (errorsProducts || !products) {
            return {
                props: {
                    products: []
                }
            };
        }
        if (errorsIntroBanner || !introBanner) {
            return {
                props: {
                    introBanner: []
                }
            };
        }
        if (errorsBlogs || !blogs) {
            return {
                props: {
                    blogs: []
                }
            };
        }
        if (errorsBanners || !banners) {
            return {
                props: {
                    blogs: []
                }
            };
        }
        return {
            props: {
                products,
                introBanner,
                blogs,
                banners
            },
            revalidate: 1
        };
    } catch (e) {
        return {
            props: {
                products: [],
                introBanner: [],
                blogs: [],
                banners: []
            },
            revalidate: 1
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 8025:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForwardOutlined");

/***/ }),

/***/ 4317:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CloseRounded");

/***/ }),

/***/ 7160:
/***/ ((module) => {

module.exports = require("@mui/icons-material/EditLocationAlt");

/***/ }),

/***/ 7372:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Favorite");

/***/ }),

/***/ 6910:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FavoriteBorder");

/***/ }),

/***/ 436:
/***/ ((module) => {

module.exports = require("@mui/icons-material/HandshakeOutlined");

/***/ }),

/***/ 6927:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LogoutTwoTone");

/***/ }),

/***/ 3365:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 759:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PersonRounded");

/***/ }),

/***/ 2749:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartOutlined");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 4989:
/***/ ((module) => {

module.exports = require("country-state-city");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 4508:
/***/ ((module) => {

module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [895,848,890,344,49,604,281], () => (__webpack_exec__(4369)));
module.exports = __webpack_exports__;

})();