(() => {
var exports = {};
exports.id = 304;
exports.ids = [304];
exports.modules = {

/***/ 5234:
/***/ ((module) => {

// Exports
module.exports = {
	"arrivalGrid": "_id__arrivalGrid__Oq29u",
	"detailsGrid2": "_id__detailsGrid2__To6Np",
	"customGrid": "_id__customGrid___Ae0_",
	"customizeOp": "_id__customizeOp__ObsbB",
	"ship": "_id__ship__mq_hj",
	"quantity1": "_id__quantity1__mjTr8",
	"qtyDiv": "_id__qtyDiv__xKO__",
	"size": "_id__size__fl2Rb",
	"qtyElementAdd": "_id__qtyElementAdd__k352w",
	"qtyElementMinus": "_id__qtyElementMinus__mg9HG",
	"productImage": "_id__productImage__TjtVb",
	"buttonInvert": "_id__buttonInvert__JUY33",
	"mainGrid": "_id__mainGrid__s_8If",
	"imgGrid": "_id__imgGrid__qknnZ",
	"imgViewGrid": "_id__imgViewGrid__E33rW",
	"productImageThumb": "_id__productImageThumb__gjbiv",
	"productImageThumbSelected": "_id__productImageThumbSelected__zpEbp",
	"contentGrid": "_id__contentGrid__ihTWi",
	"sizeGrid": "_id__sizeGrid__UMaYT",
	"desc": "_id__desc___Iqoj",
	"paymentImg": "_id__paymentImg__9m0rc",
	"productName": "_id__productName__Rs2mk",
	"productPrice": "_id__productPrice__hIewz",
	"description": "_id__description__F5RaX",
	"divider": "_id__divider___rQ2F",
	"collectionName": "_id__collectionName__VCLmM",
	"stockAvailable": "_id__stockAvailable__3Dcav",
	"stockNotAvailable": "_id__stockNotAvailable__lygBe",
	"latestArrivalsDiv": "_id__latestArrivalsDiv__NQ4dN",
	"limitedEdition": "_id__limitedEdition__lQ52Z"
};


/***/ }),

/***/ 2602:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ productDetailsPage),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(344);
/* harmony import */ var _components_productCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7049);
/* harmony import */ var _id_module_css__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5234);
/* harmony import */ var _id_module_css__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_id_module_css__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_AddOutlined__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5510);
/* harmony import */ var _mui_icons_material_AddOutlined__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddOutlined__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_RemoveRounded__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4561);
/* harmony import */ var _mui_icons_material_RemoveRounded__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_RemoveRounded__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _services_userServices__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7890);
/* harmony import */ var _context_country__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1961);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9915);
/* harmony import */ var _components_NewReleaseProductCorousel__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9604);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components__WEBPACK_IMPORTED_MODULE_2__, _components_productCard__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_11__, _services_userServices__WEBPACK_IMPORTED_MODULE_13__, _context_country__WEBPACK_IMPORTED_MODULE_14__, js_cookie__WEBPACK_IMPORTED_MODULE_17__, _components_NewReleaseProductCorousel__WEBPACK_IMPORTED_MODULE_18__]);
([_components__WEBPACK_IMPORTED_MODULE_2__, _components_productCard__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_11__, _services_userServices__WEBPACK_IMPORTED_MODULE_13__, _context_country__WEBPACK_IMPORTED_MODULE_14__, js_cookie__WEBPACK_IMPORTED_MODULE_17__, _components_NewReleaseProductCorousel__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















function productDetailsPage({ products , product , index: index1  }) {
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_15__.useSession)();
    let { 0: quantity , 1: setQuantity  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    let { 0: size , 1: setSize  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(index1 !== -1 ? Object.keys(product.inventory)[index1] : Object.keys(product.inventory)[1]);
    console.log("Size state : ", size);
    console.log("Index : ", index1);
    let { 0: images , 1: setImages  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.images);
    let { 0: inventory , 1: setInventory  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.inventory);
    let { 0: selectedImage , 1: setSelectedImage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [sizeOpen, setSizeOpen] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [auth, setAuth] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    const myData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country__WEBPACK_IMPORTED_MODULE_14__/* .Context */ ._);
    const handleClose = ()=>{
        setOpen(false);
    };
    const handleSizeClose = ()=>{
        setSizeOpen(false);
    };
    function handleUpdate(value) {
        if (inventory[size] < value && value != 0) {
            react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.error("Quantity not available!", {
                position: "top-center",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined
            });
        } else if (value == 0) {} else {
            setQuantity(value);
        }
    }
    const handleChange = (event)=>{
        const value = event.target.value;
        setSize(value);
    };
    async function addToCart(value) {
        if (session) {
            var { cart , error  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_13__/* .addItemToCart */ .dm)(product, size, quantity, session.id);
            if (error || !cart) {
                console.log("error", error);
                react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.error("Something went wrong. Please try again!", {
                    position: "top-center",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined
                });
                //signOut();
                (0,next_auth_react__WEBPACK_IMPORTED_MODULE_15__.signIn)();
            }
            if (cart) {
                if (value == 1) {
                    next_router__WEBPACK_IMPORTED_MODULE_8___default().push("../myCart");
                } else {
                    react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.success("Item added to cart", {
                        position: "top-center",
                        autoClose: 2000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined
                    });
                }
            }
        } else {
            const userCart = [];
            let currCart;
            let isPresent = false;
            const newProduct = {
                product: product,
                size: size,
                qty: quantity
            };
            if (product.inventory[size] == 0 || product.inventory[size] < quantity) {
                react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.error("Product out of stock!", {
                    position: "top-center",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined
                });
            } else {
                if (js_cookie__WEBPACK_IMPORTED_MODULE_17__["default"].get("cart")) {
                    currCart = JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_17__["default"].get("cart"));
                    currCart.map((item, i)=>{
                        if (item.product.title == newProduct.product.title && item.size == newProduct.size) {
                            item.qty = quantity;
                            isPresent = true;
                            userCart.push(item);
                        } else {
                            userCart.push(item);
                        }
                    });
                }
                if (isPresent == false || userCart.length == 0) {
                    userCart.push(newProduct);
                }
                console.log("userCart", userCart);
                js_cookie__WEBPACK_IMPORTED_MODULE_17__["default"].set("cart", JSON.stringify(userCart));
                const updatedCart = JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_17__["default"].get("cart"));
                console.log("Final cart", updatedCart);
                react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.success("Item added to cart", {
                    position: "top-center",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined
                });
                if (value == 1) {
                    next_router__WEBPACK_IMPORTED_MODULE_8___default().push("../myCart");
                }
            }
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_16___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: product.description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "distinguished,distinguished society,tee of greatness, underrated visionaries,art,creativity,The Creative Geniuses, t-shirts,Nikola Tesla Beige Tee,Oversized Fit Tee, Heavy Ribbed Neck,Oversized Fit Tee with Heavy Ribbed Neck, The Tee of Peace,Puff Print,Tee with Puff Print, The Creators Tote Bag,Tote bag,creators tee, unfinished clothing brand,legacy brand, miseducated,Unfinished,distinguished tshirt, tshirt distinguished,distinguished bags, distinguished tote bags,distinguished society tshirt, tshirt distinguished society,distinguished society tote bags, the distingushed society"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "robots",
                        content: "all"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1.0"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
                        children: [
                            product.title,
                            " | Distinguished Society"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_11__.ToastContainer, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .CountryPopup */ .Q$, {
                open: open,
                handleClose: handleClose,
                setAuth: setAuth
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Size */ .$u, {
                sizeOpen: sizeOpen,
                handleSizeClose: handleSizeClose
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Container, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().arrivalGrid),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "heading",
                                children: " Product Details"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "breadCrumb",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_7__["default"], {
                                        href: "/",
                                        children: "Home"
                                    }),
                                    " > Product details"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                        className: "insideHr"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().mainGrid),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().imgGrid),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "productImage",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().productImage),
                                                src: images[selectedImage]
                                            }),
                                            inventory[size] == 0 || inventory[size] < quantity ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().stockNotAvailable),
                                                children: "Out of Stock"
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().imgViewGrid),
                                        children: images.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                className: index == selectedImage ? (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().productImageThumbSelected) : (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().productImageThumb),
                                                src: image,
                                                onClick: ()=>setSelectedImage(index)
                                            })
                                        )
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().contentGrid),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().productName),
                                        children: product.title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().description),
                                        children: product.description
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().divider)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        style: {
                                            color: "#12B76A",
                                            fontSize: "18px"
                                        },
                                        children: product.collectionName.title
                                    }),
                                    product.isLimitedEdition ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "row",
                                        style: {
                                            margin: "24px 0px"
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().stockAvailable),
                                                children: [
                                                    product.noOfUnitsOfLimitedEdition,
                                                    " drops only"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().limitedEdition),
                                                children: "Limited Edition"
                                            })
                                        ]
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().productPrice),
                                        children:  false ? 0 : product === null || product === void 0 ? void 0 : product.price
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().sizeGrid),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Select, {
                                                onChange: (event)=>{
                                                    handleChange(event);
                                                },
                                                labelId: "select-size",
                                                id: "select-size-id",
                                                className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().size),
                                                placeholder: "Select",
                                                value: size,
                                                variant: "outlined",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "S",
                                                        children: "Size: S"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "M",
                                                        children: "Size: M"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "L",
                                                        children: "Size: L"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "XL",
                                                        children: "Size: XL"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().qtyDiv),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().qtyElementAdd),
                                                        "aria-label": "add item",
                                                        onClick: ()=>handleUpdate(quantity + 1)
                                                        ,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddOutlined__WEBPACK_IMPORTED_MODULE_5___default()), {})
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: quantity
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().qtyElementMinus),
                                                        "aria-label": "remove item",
                                                        onClick: ()=>handleUpdate(quantity - 1)
                                                        ,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_RemoveRounded__WEBPACK_IMPORTED_MODULE_6___default()), {})
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        style: {
                                            marginBottom: "30px",
                                            color: "blue",
                                            cursor: "pointer"
                                        },
                                        onClick: ()=>setSizeOpen(true)
                                        ,
                                        children: "Size Chart"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().sizeGrid),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                style: {
                                                    width: "50%"
                                                },
                                                className: "buttonInvert ",
                                                onClick: ()=>addToCart(0)
                                                ,
                                                variant: "outlined",
                                                children: "Add to Cart"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                style: {
                                                    width: "50%"
                                                },
                                                className: "buttonInvert ",
                                                variant: "outlined",
                                                onClick: ()=>addToCart(1)
                                                ,
                                                children: "Buy Now"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().ship),
                                        children: "Get free shipping on orders above Rs. 899(Only for Indian orders)"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "breadCrumb mt-5 mb-1",
                                        children: "Make payment using"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().paymentImg),
                                        src: "../assets/payment.png"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().arrivalGrid),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "heading mt-5",
                                children: "Recommended Products"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "breadCrumb"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                        className: "insideHr"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_id_module_css__WEBPACK_IMPORTED_MODULE_19___default().latestArrivalsDiv),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_NewReleaseProductCorousel__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                            products: products
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Footer */ .$_, {})
        ]
    });
};
async function getStaticPaths() {
    const { products , errorsProducts  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_13__/* .getAllProducts */ .Dg)();
    const paths = products.map((product)=>({
            params: {
                id: product.slug.toString()
            }
        })
    );
    return {
        paths,
        fallback: "blocking"
    };
}
async function getStaticProps({ params  }) {
    try {
        const { products , errorsProducts  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_13__/* .getAllProducts */ .Dg)();
        const { product , index , errorsProduct  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_13__/* .getProduct */ .wv)(params.id);
        if (errorsProducts || !products) {
            return {
                props: {
                    products: []
                }
            };
        }
        if (errorsProduct || !product) {
            return {
                props: {
                    product: []
                }
            };
        }
        return {
            props: {
                products,
                product,
                index
            },
            revalidate: 1
        };
    } catch (e) {
        return {
            props: {
                products: [],
                product: []
            },
            revalidate: 1
        };
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8308:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 5510:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/AddOutlined");

/***/ }),

/***/ 4317:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CloseRounded");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/EditLocationAlt");

/***/ }),

/***/ 7372:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Favorite");

/***/ }),

/***/ 6910:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/FavoriteBorder");

/***/ }),

/***/ 436:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/HandshakeOutlined");

/***/ }),

/***/ 6927:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LogoutTwoTone");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 759:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/PersonRounded");

/***/ }),

/***/ 4561:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/RemoveRounded");

/***/ }),

/***/ 2749:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ShoppingCartOutlined");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 4989:
/***/ ((module) => {

"use strict";
module.exports = require("country-state-city");

/***/ }),

/***/ 2296:
/***/ ((module) => {

"use strict";
module.exports = require("formik");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 1223:
/***/ ((module) => {

"use strict";
module.exports = require("react-loader-spinner");

/***/ }),

/***/ 4508:
/***/ ((module) => {

"use strict";
module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 9915:
/***/ ((module) => {

"use strict";
module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [895,848,890,344,49,604], () => (__webpack_exec__(2602)));
module.exports = __webpack_exports__;

})();