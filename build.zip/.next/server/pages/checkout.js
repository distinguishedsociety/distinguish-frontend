(() => {
var exports = {};
exports.id = 222;
exports.ids = [222];
exports.modules = {

/***/ 4874:
/***/ ((module) => {

// Exports
module.exports = {
	"arrivalGrid": "checkout_arrivalGrid__jGU9C",
	"orderDetailsMain": "checkout_orderDetailsMain__sHMP8",
	"orderDetailsMain1": "checkout_orderDetailsMain1__5Kxdj",
	"orderDetailsSub1": "checkout_orderDetailsSub1__MTuIT",
	"textField": "checkout_textField__rPulq",
	"mainGrid1": "checkout_mainGrid1__EQGOE",
	"detailsGrid": "checkout_detailsGrid__c5y92",
	"bill": "checkout_bill__3LTpz",
	"stepper": "checkout_stepper__k__Av",
	"tableKey": "checkout_tableKey__0CHfN",
	"tableValue": "checkout_tableValue__7wCYF",
	"subHeadText": "checkout_subHeadText__3FP99",
	"continueButton": "checkout_continueButton__EDkR2",
	"backButton": "checkout_backButton__9kUGb",
	"billGrid": "checkout_billGrid__Ry0tg"
};


/***/ }),

/***/ 9851:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ checkout),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(344);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4874);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_razorpay__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1040);
/* harmony import */ var react_razorpay__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_razorpay__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_countries__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(193);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _services_userServices__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7890);
/* harmony import */ var _context_country__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1961);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9915);
/* harmony import */ var country_state_city__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4989);
/* harmony import */ var country_state_city__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(country_state_city__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components__WEBPACK_IMPORTED_MODULE_2__, react_toastify__WEBPACK_IMPORTED_MODULE_9__, _services_userServices__WEBPACK_IMPORTED_MODULE_12__, _context_country__WEBPACK_IMPORTED_MODULE_13__, js_cookie__WEBPACK_IMPORTED_MODULE_15__]);
([_components__WEBPACK_IMPORTED_MODULE_2__, react_toastify__WEBPACK_IMPORTED_MODULE_9__, _services_userServices__WEBPACK_IMPORTED_MODULE_12__, _context_country__WEBPACK_IMPORTED_MODULE_13__, js_cookie__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















function checkout({ cart: cart1  }) {
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_11__.useSession)();
    const myData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country__WEBPACK_IMPORTED_MODULE_13__/* .Context */ ._);
    console.log(myData);
    const steps = [
        "Order details",
        "Shipping details",
        "Payment"
    ];
    let { 0: shippingRate , 1: setShippingRate  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [activeStep, setActiveStep] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(0);
    const [skipped, setSkipped] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(new Set());
    let { 0: cartItems , 1: setCartItems  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(cart1);
    let { 0: isLoading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    let { 0: no_of_products , 1: setProducts  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    var { 0: subtotal , 1: setSubtotal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    var { 0: tax , 1: setTax  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    var { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    let { 0: address , 1: setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: countryCode , 1: setCountryCode  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: country , 1: setCountry  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(country_state_city__WEBPACK_IMPORTED_MODULE_16__.Country.getCountryByCode(myData.value.countryCode));
    let sum = 0;
    const Razorpay = react_razorpay__WEBPACK_IMPORTED_MODULE_5___default()();
    // const BASE_URL = 'https://www.thedistinguishedsociety.com/internal/api/users'
    const BASE_URL = "http://localhost:3002/internal/api/users";
    const { 0: deliveryOptions , 1: setDeliveryOptions  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!session) {
            if (js_cookie__WEBPACK_IMPORTED_MODULE_15__["default"].get("cart")) cart1 = JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_15__["default"].get("cart"));
        }
        if (cart1) {
            setCartItems(cart1);
            setProducts(Object.keys(cart1).length);
            cart1.map((product, index)=>{
                sum = parseInt(sum) + parseInt(product.product.price);
            });
            setSubtotal(sum);
            setTax(0.12 * parseInt(subtotal));
            setTotal(parseInt(subtotal) + parseInt(shippingRate));
            localStorage.setItem("order_type", "Prepaid");
            setLoading(false);
        } else {
            setLoading(false);
        }
    //getCartProducts();
    }, []);
    async function checkShippingPrice() {
        setLoading(true);
        if (country.isoCode == "IN") {
            setShippingRate(0);
            setLoading(false);
            activeStep == 0 && handleNext();
        } else {
            //   const country = await countries.filter(function (i, n) {
            //     return i.countryName == address.delivery_country
            //   })
            const code = country.isoCode;
            setCountryCode(code);
            setShippingRate(823.22);
            console.log("to check order type", code);
            // if (code) {
            //   let shippingData = {
            //     pincode: address.pincode,
            //     delivery_country: country.isoCode,
            //     order_type: "Prepaid",
            //     cart : JSON.parse(Cookies.get("cart"))
            //   }
            //   console.log("shipping details" ,shippingData )
            //   let res = await axios({
            //     url: `https://www.thedistinguishedsociety.com/internal/api/users/fetchCartDeliveryOptions`,
            //     method: 'POST',
            //     // headers: {
            //     //   authorization: `Bearer ${session.id}`,
            //     // },
            //     data: shippingData,
            //   })
            //   if (res.data.status == 'success') {
            //     setLoading(false)
            //     setShippingRate(res.data.data.rate.rate)
            //     setDeliveryOptions(res.data.data)
            //     handleNext()
            //   } else {
            //     setLoading(false)
            //     toast.error('Something went wrong. Please try again', {
            //       position: 'top-center',
            //       autoClose: 2000,
            //       hideProgressBar: false,
            //       closeOnClick: true,
            //       pauseOnHover: true,
            //       draggable: true,
            //       progress: undefined,
            //     })
            //   }
            //   setLoading(false)
            // } else {
            //   setLoading(false)
            //   toast.error('Something went wrong. Please try again', {
            //     position: 'top-center',
            //     autoClose: 2000,
            //     hideProgressBar: false,
            //     closeOnClick: true,
            //     pauseOnHover: true,
            //     draggable: true,
            //     progress: undefined,
            //   })
            // }
            setLoading(false);
            handleNext();
        }
    }
    const handleNext = ()=>{
        setActiveStep((prevActiveStep)=>prevActiveStep + 1
        );
    };
    const handleBack = ()=>{
        setActiveStep((prevActiveStep)=>prevActiveStep - 1
        );
    };
    async function proceedToPay() {
        setLoading(true);
        const data = {
            firstname: address.firstname,
            lastname: address.lastname,
            email: address.email,
            address: address.address,
            landmark: address.landmark,
            state: address.state.name,
            city: address.city,
            isInternational: address.isInternational,
            pincode: address.pincode,
            country: country.name,
            delivery_country: country.isoCode,
            order_type: address.order_type,
            phoneNumber: address.phoneNumber
        };
        console.log(address);
        console.log("data", data);
        const cart = JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_15__["default"].get("cart"));
        const guestData = {
            ...data,
            cart
        };
        console.log("guest data", guestData);
        let res1;
        await axios__WEBPACK_IMPORTED_MODULE_4___default()(session ? {
            url: `${BASE_URL}/placeOrder`,
            method: "POST",
            headers: {
                authorization: `Bearer ${session.id}`
            },
            data: data
        } : {
            url: `${BASE_URL}/placeGuestOrder`,
            method: "POST",
            data: guestData
        }).then((res)=>{
            console.log("response", res);
            if (data.order_type == "Prepaid" || guestData.order_type == "Prepaid") {
                console.log("inside");
                setLoading(false);
                var options = {
                    key_id: "rzp_live_HRTCJnxkRyWNF2",
                    amount: res.data.data.paymentId.amount * myData.value.currencyRate,
                    currency: "INR",
                    name: "Distinguished Society",
                    description: "Order Payment",
                    order_id: res.data.data.paymentId.id,
                    handler: function(response) {
                        if (response.razorpay_payment_id) {
                            setLoading(true);
                            next_router__WEBPACK_IMPORTED_MODULE_6___default().push({
                                pathname: "../orderStatus",
                                query: {
                                    amount: total,
                                    est_date: res.data.data.etd
                                }
                            });
                        }
                    },
                    prefill: {
                        name: address.firstname,
                        email: address.email,
                        contact: address.phoneNumber
                    },
                    notes: {
                        address: "Razorpay Corporate Office"
                    }
                };
                console.log("payment options", options);
                const paymentObject = new window.Razorpay(options);
                paymentObject.open();
                paymentObject.on("payment.failed", function(res) {});
            } else {
                setLoading(true);
                next_router__WEBPACK_IMPORTED_MODULE_6___default().push({
                    pathname: "../orderStatus",
                    query: {
                        amount: total,
                        est_date: res.data.data.etd
                    }
                });
                setLoading(false);
            }
        }).catch((error)=>{
            setLoading(false);
            react_toastify__WEBPACK_IMPORTED_MODULE_9__.toast.error("Something went wrong. Please try again", {
                position: "top-center",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined
            });
        });
        if (!res1) {
            react_toastify__WEBPACK_IMPORTED_MODULE_9__.toast.error("Something went wrong. Please try again", {
                position: "top-center",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined
            });
        }
    }
    function displayStepContent(index) {
        switch(index){
            case 0:
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .AddressDetails */ .Ec, {
                    handleNext: handleNext,
                    handleBack: handleBack,
                    setAddress: setAddress,
                    address: address,
                    setLoading: setLoading,
                    checkShippingPrice: checkShippingPrice,
                    country: country,
                    setCountry: setCountry
                });
                break;
            case 1:
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .ShipmentDetails */ .IL, {
                    handleNext: handleNext,
                    handleBack: handleBack,
                    address: address,
                    setAddress: setAddress,
                    checkShippingPrice: checkShippingPrice,
                    country: country,
                    setCountry: setCountry
                });
                break;
            case 2:
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Payment */ .F6, {
                    handleNext: handleNext,
                    handleBack: handleBack,
                    address: address,
                    setAddress: setAddress
                });
                break;
        }
    }
    if (isLoading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "mainpage d-flex justify-content-center align-items-center flex-column bg-gray-50",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_7__.Triangle, {
                color: "black",
                height: 60,
                width: 60
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_9__.ToastContainer, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_14___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "distinguished,distinguished society,tee of greatness, underrated visionaries,art,creativity,The Creative Geniuses, t-shirts,Nikola Tesla Beige Tee,Oversized Fit Tee, Heavy Ribbed Neck,Oversized Fit Tee with Heavy Ribbed Neck, The Tee of Peace,Puff Print,Tee with Puff Print, The Creators Tote Bag,Tote bag,creators tee, unfinished clothing brand,legacy brand, miseducated,Unfinished,distinguished tshirt, tshirt distinguished,distinguished bags, distinguished tote bags,distinguished society tshirt, tshirt distinguished society,distinguished society tote bags, the distingushed society"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "robots",
                        content: "noindex,nofollow"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1.0"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: " Checkout | Distinguished Society"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Container, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().arrivalGrid),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "heading",
                            children: "Checkout"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Stepper, {
                        activeStep: activeStep,
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().stepper),
                        children: steps.map((label, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Step, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.StepLabel, {
                                    children: label
                                })
                            }, label);
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().mainGrid1),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                    children: [
                                        displayStepContent(activeStep),
                                        activeStep != 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().backButton),
                                            onClick: ()=>handleBack()
                                            ,
                                            variant: "outlined",
                                            children: "Back"
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().billGrid),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().arrivalGrid),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().subHeadText),
                                            children: "Order Summary"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().bill),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableKey),
                                                            children: "Products"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableValue),
                                                            children: no_of_products
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableKey),
                                                            children: "Subtotal"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableValue),
                                                            children: (subtotal * myData.value.currencyRate).toFixed(2)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableKey),
                                                            children: "Shipping"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableValue),
                                                            children: (shippingRate * myData.value.currencyRate).toFixed(2)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableKey),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {})
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableValue),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {})
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableKey),
                                                            children: "Total"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableValue),
                                                            children: ((parseFloat(subtotal) + parseFloat(shippingRate)) * myData.value.currencyRate).toFixed(2)
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    activeStep != 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().continueButton),
                                        onClick: ()=>proceedToPay()
                                        ,
                                        variant: "outlined",
                                        children: "Proceed to Pay"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Footer */ .$_, {})
        ]
    });
};
async function getServerSideProps(context) {
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_11__.getSession)(context);
    try {
        var { cart , error  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_12__/* .getCart */ .dv)(session.id);
        if (error || !cart) {
            return {
                props: {
                    cart: []
                }
            };
        }
        return {
            props: {
                cart: cart
            }
        };
    } catch (e) {
        return {
            props: {
                cart: []
            }
        };
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8308:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 4317:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CloseRounded");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/EditLocationAlt");

/***/ }),

/***/ 6910:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/FavoriteBorder");

/***/ }),

/***/ 436:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/HandshakeOutlined");

/***/ }),

/***/ 6927:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LogoutTwoTone");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 759:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/PersonRounded");

/***/ }),

/***/ 2749:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ShoppingCartOutlined");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 4989:
/***/ ((module) => {

"use strict";
module.exports = require("country-state-city");

/***/ }),

/***/ 2296:
/***/ ((module) => {

"use strict";
module.exports = require("formik");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 1223:
/***/ ((module) => {

"use strict";
module.exports = require("react-loader-spinner");

/***/ }),

/***/ 1040:
/***/ ((module) => {

"use strict";
module.exports = require("react-razorpay");

/***/ }),

/***/ 4508:
/***/ ((module) => {

"use strict";
module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 9915:
/***/ ((module) => {

"use strict";
module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [895,848,890,344], () => (__webpack_exec__(9851)));
module.exports = __webpack_exports__;

})();