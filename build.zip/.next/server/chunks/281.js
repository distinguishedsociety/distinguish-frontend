exports.id = 281;
exports.ids = [281];
exports.modules = {

/***/ 3266:
/***/ ((module) => {

// Exports
module.exports = {
	"mainGrid": "home_mainGrid__eD07F",
	"grid1": "home_grid1__rILf2",
	"grid2": "home_grid2__NLjVw",
	"subGrid": "home_subGrid__fNYm3",
	"arrivalGrid": "home_arrivalGrid___kZ_E",
	"displayProductGrid": "home_displayProductGrid__PPsCj",
	"latestArrivalsDiv": "home_latestArrivalsDiv__5JKRI",
	"home-product-div": "home_home-product-div__E7rQh",
	"blogsDiv": "home_blogsDiv__nDFAH",
	"blogDetails": "home_blogDetails__m9IZO",
	"blogSubDetails": "home_blogSubDetails__fZpEV",
	"video": "home_video__5wSil",
	"contactDiv": "home_contactDiv__ii5Ec",
	"blogButtonGrid": "home_blogButtonGrid__wCErr",
	"subHeadingDiv": "home_subHeadingDiv__zssDm",
	"contact": "home_contact__JoL3t",
	"email": "home_email__ryHw2",
	"gridItem": "home_gridItem__2nLUe",
	"bannerImage": "home_bannerImage__gNtF3",
	"heading": "home_heading__QqV4m",
	"mainGridResponsive": "home_mainGridResponsive__ONyE_",
	"offereImages": "home_offereImages__0ML_A",
	"grid1Responsive": "home_grid1Responsive__ijibu"
};


/***/ }),

/***/ 2281:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(344);
/* harmony import */ var _components_productCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7049);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3266);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var _mui_icons_material_ArrowForwardOutlined__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8025);
/* harmony import */ var _mui_icons_material_ArrowForwardOutlined__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ArrowForwardOutlined__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _services_userServices__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7890);
/* harmony import */ var _context_country__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1961);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_NewReleaseProductCorousel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9604);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components__WEBPACK_IMPORTED_MODULE_2__, _components_productCard__WEBPACK_IMPORTED_MODULE_3__, _services_userServices__WEBPACK_IMPORTED_MODULE_7__, _context_country__WEBPACK_IMPORTED_MODULE_8__, _components_NewReleaseProductCorousel__WEBPACK_IMPORTED_MODULE_10__]);
([_components__WEBPACK_IMPORTED_MODULE_2__, _components_productCard__WEBPACK_IMPORTED_MODULE_3__, _services_userServices__WEBPACK_IMPORTED_MODULE_7__, _context_country__WEBPACK_IMPORTED_MODULE_8__, _components_NewReleaseProductCorousel__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const landingPage = ({ products , introBanner , blogs , banners  })=>{
    const myData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country__WEBPACK_IMPORTED_MODULE_8__/* .Context */ ._);
    const [country, setCountry] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_9___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Distinguished Society is for the upcoming visionaries, the ones who speak with their art and creativity. The ones who choose the harder path for a greater purpose. The ones who believe that creativity is the measure of a persons greatness. The Creative Geniuses."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "distinguished,distinguished society,tee of greatness, underrated visionaries,art,creativity,The Creative Geniuses, t-shirts,Nikola Tesla Beige Tee,Oversized Fit Tee, Heavy Ribbed Neck,Oversized Fit Tee with Heavy Ribbed Neck, The Tee of Peace,Puff Print,Tee with Puff Print, The Creators Tote Bag,Tote bag,creators tee, unfinished clothing brand,legacy brand, miseducated,Unfinished,distinguished tshirt, tshirt distinguished,distinguished bags, distinguished tote bags,distinguished society tshirt, tshirt distinguished society,distinguished society tote bags, the distingushed society"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "robots",
                        content: "all"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1.0"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Distinguished Society"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .OfferImages */ .lL, {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_11___default().offereImages),
                banners: banners
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Container, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "d-flex",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            className: "text-mute mt-4 mb-0",
                            children: "Shop our exclusive drops"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_11___default().latestArrivalsDiv),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_NewReleaseProductCorousel__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                products: products
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_5__["default"], {
                                href: "../products",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                    className: "button showButton mx-auto w-1/4",
                                    variant: "outlined",
                                    children: [
                                        "Show more",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ArrowForwardOutlined__WEBPACK_IMPORTED_MODULE_6___default()), {})
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Footer */ .$_, {})
        ]
    });
};
async function getStaticProps() {
    try {
        const { products , errorsProducts  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_7__/* .getAllProducts */ .Dg)();
        const { introBanner , errorsIntroBanner  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_7__/* .getIntroBanner */ .zG)();
        const { banners , errorsBanners  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_7__/* .getBanners */ .Ey)();
        const { blogs , errorsBlogs  } = await (0,_services_userServices__WEBPACK_IMPORTED_MODULE_7__/* .getAllBlogs */ .L)();
        if (errorsProducts || !products) {
            return {
                props: {
                    products: []
                }
            };
        }
        if (errorsIntroBanner || !introBanner) {
            return {
                props: {
                    introBanner: []
                }
            };
        }
        if (errorsBlogs || !blogs) {
            return {
                props: {
                    blogs: []
                }
            };
        }
        if (errorsBanners || !banners) {
            return {
                props: {
                    blogs: []
                }
            };
        }
        return {
            props: {
                products,
                introBanner,
                blogs,
                banners
            },
            revalidate: 1
        };
    } catch (e) {
        return {
            props: {
                products: [],
                introBanner: [],
                blogs: [],
                banners: []
            },
            revalidate: 1
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (landingPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;