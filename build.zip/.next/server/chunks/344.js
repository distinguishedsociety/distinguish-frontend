exports.id = 344;
exports.ids = [344];
exports.modules = {

/***/ 9862:
/***/ ((module) => {

// Exports
module.exports = {
	"invoiceDiv": "orderHistory_invoiceDiv__Wrn_F",
	"detailsDiv": "orderHistory_detailsDiv__Nh2kn",
	"subDiv": "orderHistory_subDiv__dpqFv",
	"products": "orderHistory_products__gRy6Q",
	"productImages": "orderHistory_productImages__3cmUZ",
	"imageDiv": "orderHistory_imageDiv__WyhLu",
	"download": "orderHistory_download__TQBBD"
};


/***/ }),

/***/ 4126:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "shipmentDetails_main__3f45e",
	"freeDelivery": "shipmentDetails_freeDelivery__H3W5K",
	"subHeadText": "shipmentDetails_subHeadText__fqq9t"
};


/***/ }),

/***/ 4765:
/***/ ((module) => {

// Exports
module.exports = {
	"arrivalGrid": "addressDetails_arrivalGrid__mNvv3",
	"orderDetailsMain": "addressDetails_orderDetailsMain__pqrKL",
	"orderDetailsMain1": "addressDetails_orderDetailsMain1__HInXj",
	"orderDetailsSub1": "addressDetails_orderDetailsSub1__0HTtA",
	"textField": "addressDetails_textField__VDPz1",
	"mainGrid1": "addressDetails_mainGrid1__E1CV_",
	"detailsGrid": "addressDetails_detailsGrid__SZdNm",
	"bill": "addressDetails_bill__ZhFb9",
	"stepper": "addressDetails_stepper__WQy1L",
	"continueButton": "addressDetails_continueButton__jPtqC",
	"errors": "addressDetails_errors__wKhCJ",
	"inputField": "addressDetails_inputField__ZeLe6"
};


/***/ }),

/***/ 7577:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ addressDetails)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4765);
/* harmony import */ var _styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _context_country__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1961);
/* harmony import */ var country_state_city__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4989);
/* harmony import */ var country_state_city__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(country_state_city__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _services_userServices__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7890);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _context_country__WEBPACK_IMPORTED_MODULE_4__, _services_userServices__WEBPACK_IMPORTED_MODULE_6__, react_toastify__WEBPACK_IMPORTED_MODULE_7__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _context_country__WEBPACK_IMPORTED_MODULE_4__, _services_userServices__WEBPACK_IMPORTED_MODULE_6__, react_toastify__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function addressDetails(props1) {
    var ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, ref10;
    const myData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country__WEBPACK_IMPORTED_MODULE_4__/* .Context */ ._);
    console.log(myData);
    const [countryInputValue, setCountryInputValue] = react__WEBPACK_IMPORTED_MODULE_1___default().useState();
    // const [country, setCountry] = useState(Country.getCountryByCode(myData.value.countryCode))
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [stateInputValue, setStateInputValue] = react__WEBPACK_IMPORTED_MODULE_1___default().useState();
    var _country;
    const [data1, setData] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({
        firstname: "",
        lastname: "",
        email: "",
        isInternational: false,
        address: "",
        landmark: "",
        state: "",
        city: "",
        delivery_country: (_country = myData.value.country) !== null && _country !== void 0 ? _country : localStorage.getItem("country"),
        pincode: "",
        order_type: "Prepaid",
        phoneNumber: ""
    });
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (Object.keys(props1.address).length > 0) {
            let newData = {
                ...data1
            };
            Object.keys(props1.address).map((key, i)=>{
                newData[key] = Object.values(props1.address)[i];
            });
            setData(newData);
        }
    }, []);
    const handleInputChange = (e)=>{
        let newData = {
            ...data1
        };
        newData[e.target.id] = e.target.value;
        setData(newData);
    };
    const continueShipment = async (formData)=>{
        console.log(formData);
        console.log("Hello");
        setData(formData);
        if (props1.country.name != "India") {
            let newData = {
                ...formData,
                isInternational: true,
                delivery_country: props1.country.isoCode,
                state: state
            };
            newData["isInternational"] = true;
            setData(newData);
            props1.setAddress(newData);
        } else {
            let newData = {
                ...formData,
                isInternational: false,
                delivery_country: props1.country.isoCode,
                state: state
            };
            newData["isInternational"] = false;
            setData(newData);
            props1.setAddress(newData);
        }
        props1.setLoading(true);
        console.log("addressDetails: ", formData.pincode);
        // const {data, error} = await fetchDeliveryOptions()
        props1.checkShippingPrice();
        props1.setLoading(false);
    // if(error){
    //   props.setLoading(false)
    //   toast.error(error)
    // }else{
    //   console.log(data)
    //   props.setLoading(false)
    // }
    // props.handleNext()
    };
    const { register , handleSubmit , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
        mode: "all",
        reValidateMode: "onChange"
    });
    console.log(country_state_city__WEBPACK_IMPORTED_MODULE_5__.State.getStatesOfCountry(myData.value.countryCode));
    console.log(data1);
    var _name;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Container, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().mainGrid1),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().detailsGrid),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    onSubmit: handleSubmit((data)=>continueShipment(data)
                    ),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().orderDetailsMain1),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    children: "Order details"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Autocomplete, {
                                    name: "country",
                                    id: "country-select-demo",
                                    sx: {
                                        width: "100%"
                                    },
                                    options: country_state_city__WEBPACK_IMPORTED_MODULE_5__.Country.getAllCountries(),
                                    autoHighlight: true,
                                    displayEmpty: true,
                                    value: props1.country,
                                    onChange: (event, newValue)=>{
                                        props1.setCountry(newValue);
                                        setState();
                                    },
                                    inputValue: countryInputValue,
                                    onInputChange: (event, newInputValue)=>{
                                        setCountryInputValue(newInputValue);
                                        setStateInputValue("");
                                    },
                                    getOptionLabel: (option)=>option.name
                                    ,
                                    renderOption: (props, option)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                            component: "li",
                                            sx: {
                                                "& > img": {
                                                    mr: 2,
                                                    flexShrink: 0
                                                }
                                            },
                                            ...props,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    loading: "lazy",
                                                    width: "20",
                                                    src: `https://flagcdn.com/w20/${option.isoCode.toLowerCase()}.png`,
                                                    srcSet: `https://flagcdn.com/w40/${option.isoCode.toLowerCase()}.png 2x`,
                                                    alt: ""
                                                }),
                                                option.name,
                                                " (",
                                                option.isoCode,
                                                ")"
                                            ]
                                        })
                                    ,
                                    renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            ...params,
                                            placeholder: "Choose a country",
                                            inputProps: {
                                                ...params.inputProps,
                                                autoComplete: "new-password"
                                            },
                                            required: true
                                        })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Autocomplete, {
                                    name: "country",
                                    id: "country-select-demo",
                                    sx: {
                                        width: "100%"
                                    },
                                    options: props1.country ? country_state_city__WEBPACK_IMPORTED_MODULE_5__.State.getStatesOfCountry(props1.country.isoCode) : [],
                                    autoHighlight: true,
                                    displayEmpty: true,
                                    value: state,
                                    onChange: (event, newValue)=>{
                                        setState(newValue);
                                    },
                                    inputValue: countryInputValue,
                                    onInputChange: (event, newInputValue)=>{
                                        setStateInputValue(newInputValue);
                                    },
                                    getOptionLabel: (option)=>(_name = option.name) !== null && _name !== void 0 ? _name : ""
                                    ,
                                    renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            ...params,
                                            placeholder: "Select State",
                                            inputProps: {
                                                ...params.inputProps,
                                                autoComplete: "new-password"
                                            },
                                            required: true
                                        })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                    ...register("firstname", {
                                        required: true
                                    }),
                                    id: "firstname",
                                    label: "First Name",
                                    variant: "outlined",
                                    size: "small",
                                    className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().inputField)
                                }),
                                errors.firstname && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: ((ref = errors.firstname) === null || ref === void 0 ? void 0 : ref.type) === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "error",
                                        children: "Firstname is required"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                    ...register("lastname", {
                                        required: true
                                    }),
                                    id: "lastname",
                                    label: "Last Name",
                                    variant: "outlined",
                                    size: "small"
                                }),
                                errors.lastname && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: ((ref1 = errors.lastname) === null || ref1 === void 0 ? void 0 : ref1.type) === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "error",
                                        children: "Lastname is required"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().orderDetailsSub1),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().errors),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                                    ...register("phoneNumber", {
                                                        required: true,
                                                        maxLength: 10,
                                                        minLength: 10
                                                    }),
                                                    id: "phoneNumber",
                                                    label: "Contact Number",
                                                    variant: "outlined",
                                                    size: "small",
                                                    className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().textField)
                                                }),
                                                errors.phoneNumber && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        ((ref2 = errors.phoneNumber) === null || ref2 === void 0 ? void 0 : ref2.type) === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "error",
                                                            children: "Phone Number is required"
                                                        }),
                                                        ((ref3 = errors.phoneNumber) === null || ref3 === void 0 ? void 0 : ref3.type) === "maxLength" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "error",
                                                            children: "Invalid Phone Number"
                                                        }),
                                                        ((ref4 = errors.phoneNumber) === null || ref4 === void 0 ? void 0 : ref4.type) === "minLength" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "error",
                                                            children: "Invalid Phone Number"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().errors),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                                    ...register("email", {
                                                        required: true,
                                                        pattern: /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/i
                                                    }),
                                                    id: "email",
                                                    label: "Email ID",
                                                    variant: "outlined",
                                                    size: "small",
                                                    className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().textField)
                                                }),
                                                errors.email && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        ((ref5 = errors.email) === null || ref5 === void 0 ? void 0 : ref5.type) === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "error",
                                                            children: "Email is required"
                                                        }),
                                                        ((ref6 = errors.email) === null || ref6 === void 0 ? void 0 : ref6.type) === "pattern" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "error",
                                                            children: "Invalid Email"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().orderDetailsMain1),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    children: "Add new address"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                    ...register("address", {
                                        required: true
                                    }),
                                    id: "address",
                                    placeholder: "Enter shipping address in detail",
                                    multiline: true,
                                    minRows: 4,
                                    variant: "outlined",
                                    size: "small"
                                }),
                                errors.address && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: ((ref7 = errors.address) === null || ref7 === void 0 ? void 0 : ref7.type) === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "error",
                                        children: "Address is required"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                    ...register("landmark", {
                                        required: true
                                    }),
                                    id: "landmark",
                                    label: "Landmark",
                                    variant: "outlined",
                                    size: "small",
                                    className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().textField)
                                }),
                                errors.landmark && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: ((ref8 = errors.landmark) === null || ref8 === void 0 ? void 0 : ref8.type) === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "error",
                                        children: "Landmark is required"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().orderDetailsSub1),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().errors),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                                    ...register("pincode", {
                                                        required: true
                                                    }),
                                                    id: "pincode",
                                                    label: "Zip Code",
                                                    variant: "outlined",
                                                    size: "small",
                                                    className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().textField)
                                                }),
                                                errors.pincode && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: ((ref9 = errors.pincode) === null || ref9 === void 0 ? void 0 : ref9.type) === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "error",
                                                        children: "Pincode is required"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().errors),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                                    ...register("city", {
                                                        required: true
                                                    }),
                                                    id: "city",
                                                    label: "City",
                                                    variant: "outlined",
                                                    size: "small",
                                                    className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().textField)
                                                }),
                                                errors.city && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: ((ref10 = errors.city) === null || ref10 === void 0 ? void 0 : ref10.type) === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "error",
                                                        children: "City is required"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            className: (_styles_addressDetails_module_css__WEBPACK_IMPORTED_MODULE_8___default().continueButton),
                            style: {
                                backgroundColor: "black",
                                color: "white"
                            },
                            type: "submit",
                            variant: "outlined",
                            children: "Countinue Shipment"
                        })
                    ]
                })
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3713:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BlogCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);




function BlogCard(props) {
    const blogDetails = props.data;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "carDiv",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: "blogImage",
                    src: blogDetails.bannerLink
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "blogName",
                    children: blogDetails.title
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                    href: `../blogs/${blogDetails._id}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        className: "button w-full mt-5",
                        variant: "outlined",
                        children: "Read This Blog"
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 9289:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CountryPopup)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4317);
/* harmony import */ var _mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_countries_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(193);
/* harmony import */ var _services_currencyConversion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6883);
/* harmony import */ var _context_country__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1961);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_country__WEBPACK_IMPORTED_MODULE_8__]);
_context_country__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









function CountryPopup(props1) {
    const countriesList = _utils_countries_js__WEBPACK_IMPORTED_MODULE_6__/* .countries */ .h;
    const myData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country__WEBPACK_IMPORTED_MODULE_8__/* .Context */ ._);
    //const [selectedCountry , setSelectedCountry] = React.useState(myData.value);
    const [inputValue, setInputValue] = react__WEBPACK_IMPORTED_MODULE_1___default().useState();
    const [value1, setValue] = react__WEBPACK_IMPORTED_MODULE_1___default().useState();
    const [error, setError] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    async function setCountry() {
        localStorage.setItem("country", inputValue);
        const country = await _utils_countries_js__WEBPACK_IMPORTED_MODULE_6__/* .countries.filter */ .h.filter(function(i, n) {
            return i.countryName == inputValue;
        });
        let response, error;
        if (country) {
            const countryCode = country[0].currencyCode;
            localStorage.setItem("countryCode", country[0].countryCode);
            response = await (0,_services_currencyConversion__WEBPACK_IMPORTED_MODULE_7__/* .convertCurrency */ .N)(countryCode);
        }
        if (response) {
            props1.setCountry(inputValue);
            const value = {
                country: localStorage.getItem("country"),
                currency: localStorage.getItem("currency"),
                currencyRate: localStorage.getItem("currencyRate"),
                countryCode: localStorage.getItem("countryCode")
            };
            myData.setValue(value);
            //setSelectedCountry(myData.value)
            props1.handleClose();
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_3__.Formik, {
            initialValues: {
                country: props1.country
            },
            validationSchema: yup__WEBPACK_IMPORTED_MODULE_4__.object({
                country: yup__WEBPACK_IMPORTED_MODULE_4__.string().required("Please select your country")
            }),
            onSubmit: (values, { setSubmitting  })=>{
                const res = setCountry();
                if (res) {
                    props1.setCountry(inputValue);
                    props1.handleClose();
                }
                setSubmitting(false);
            },
            children: (formik)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Dialog, {
                    open: props1.open,
                    "aria-labelledby": "responsive-dialog-title",
                    onClose: props1.handleClose,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: "formClose",
                            onClick: props1.handleClose
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Container, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.DialogActions, {
                                className: "loginFormGrid",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    onSubmit: formik.handleSubmit,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-red-600 text-sm",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_3__.ErrorMessage, {
                                                name: "username"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Autocomplete, {
                                            autoComplete: "off",
                                            name: "country",
                                            id: "country-select-demo",
                                            sx: {
                                                width: 300
                                            },
                                            options: _utils_countries_js__WEBPACK_IMPORTED_MODULE_6__/* .countries */ .h,
                                            style: {
                                                marginBottom: "20px",
                                                marginTop: "20px"
                                            },
                                            autoHighlight: true,
                                            value: value1,
                                            displayEmpty: true,
                                            onChange: (event, newValue)=>{
                                                setValue(newValue);
                                            },
                                            inputValue: inputValue,
                                            onInputChange: (event, newInputValue)=>{
                                                setInputValue(newInputValue);
                                            },
                                            getOptionLabel: (option)=>option.countryName
                                            ,
                                            renderOption: (props, option)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
                                                    component: "li",
                                                    sx: {
                                                        "& > img": {
                                                            mr: 2,
                                                            flexShrink: 0
                                                        }
                                                    },
                                                    ...props,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            loading: "lazy",
                                                            width: "20",
                                                            src: `https://flagcdn.com/w20/${option.countryCode.toLowerCase()}.png`,
                                                            srcSet: `https://flagcdn.com/w40/${option.countryCode.toLowerCase()}.png 2x`,
                                                            alt: ""
                                                        }),
                                                        option.countryName,
                                                        " (",
                                                        option.countryCode,
                                                        ")"
                                                    ]
                                                })
                                            ,
                                            renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.TextField, {
                                                    ...params,
                                                    placeholder: "Choose a country",
                                                    inputProps: {
                                                        ...params.inputProps,
                                                        autoComplete: "new-password"
                                                    }
                                                })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                            onClick: ()=>setCountry()
                                            ,
                                            className: "buttonInvert w-full",
                                            style: {
                                                margiTop: "18px"
                                            },
                                            children: "Continue"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3447:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var _context_country__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1961);
/* harmony import */ var _countryPopup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9289);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_country__WEBPACK_IMPORTED_MODULE_4__, _countryPopup__WEBPACK_IMPORTED_MODULE_5__]);
([_context_country__WEBPACK_IMPORTED_MODULE_4__, _countryPopup__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function footer() {
    const myData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country__WEBPACK_IMPORTED_MODULE_4__/* .Context */ ._);
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [country, setCountry] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(myData.value.country);
    const handleClose = ()=>{
        setOpen(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "footer ",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Container, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mainContentFooter",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "div1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "footerLogo",
                                        src: "../assets/TDS FINAL LOGO WHITE.png"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                children: "DISTINGUISHED SOCIETY"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: "A product of Indian Origin."
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "RespDivFooter",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "div2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                href: "../products",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "inline footerLink",
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: "Our collection"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                href: "../products",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "inline footerLink",
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: "New arrivals"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                href: "../blogs",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "inline footerLink",
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: "Blogs"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                className: "inline footerLink",
                                                style: {
                                                    cursor: "pointer"
                                                },
                                                onClick: ()=>setOpen(true)
                                                ,
                                                children: [
                                                    "Shipping to :  ",
                                                    myData.value.country
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                href: "../AffiliateProgram",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "inline footerLink",
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: "Become an Affiliate"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "div3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                href: "../contactUs",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "inline footerLink",
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: "Contact us"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                href: "../termsAndConditions",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "inline footerLink",
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: "Terms & conditions"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                href: "../privacyPolicy",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "inline footerLink",
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: "Privacy Policy"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                href: "../shippingAndReturn",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "inline footerLink",
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: "Shipping and Return Policy"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "subContentFooter",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "@2022 Distinguished society | All Rights Reserved"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "../assets/payment.png"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-4 methods",
                                        children: "Payment methods Accepted "
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_countryPopup__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                open: open,
                handleClose: handleClose,
                country: country,
                setCountry: setCountry
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 344:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$_": () => (/* reexport safe */ _footer__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "W_": () => (/* reexport safe */ _navigation__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "$h": () => (/* reexport safe */ _blogCard__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "Q$": () => (/* reexport safe */ _countryPopup__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "lL": () => (/* reexport safe */ _offerImages__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "Ec": () => (/* reexport safe */ _addressDetails__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "IL": () => (/* reexport safe */ _shipmentDetails__WEBPACK_IMPORTED_MODULE_7__.Z),
/* harmony export */   "F6": () => (/* reexport safe */ _payment__WEBPACK_IMPORTED_MODULE_8__.Z),
/* harmony export */   "We": () => (/* reexport safe */ _orderHistory__WEBPACK_IMPORTED_MODULE_9__.Z),
/* harmony export */   "$u": () => (/* reexport safe */ _sizeChart__WEBPACK_IMPORTED_MODULE_10__.Z)
/* harmony export */ });
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3447);
/* harmony import */ var _navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2273);
/* harmony import */ var _blogCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3713);
/* harmony import */ var _countryPopup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9289);
/* harmony import */ var _profileSidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7709);
/* harmony import */ var _offerImages__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2867);
/* harmony import */ var _addressDetails__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7577);
/* harmony import */ var _shipmentDetails__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6765);
/* harmony import */ var _payment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9861);
/* harmony import */ var _orderHistory__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5745);
/* harmony import */ var _sizeChart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9922);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_footer__WEBPACK_IMPORTED_MODULE_0__, _navigation__WEBPACK_IMPORTED_MODULE_1__, _countryPopup__WEBPACK_IMPORTED_MODULE_3__, _addressDetails__WEBPACK_IMPORTED_MODULE_6__, _payment__WEBPACK_IMPORTED_MODULE_8__]);
([_footer__WEBPACK_IMPORTED_MODULE_0__, _navigation__WEBPACK_IMPORTED_MODULE_1__, _countryPopup__WEBPACK_IMPORTED_MODULE_3__, _addressDetails__WEBPACK_IMPORTED_MODULE_6__, _payment__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










 // export {default as Invoice} from './invoice'

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2273:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ navigation)
/* harmony export */ });
/* unused harmony export getServerSideProps */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_ShoppingCartOutlined__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2749);
/* harmony import */ var _mui_icons_material_ShoppingCartOutlined__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ShoppingCartOutlined__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6910);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_HandshakeOutlined__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(436);
/* harmony import */ var _mui_icons_material_HandshakeOutlined__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HandshakeOutlined__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var _countryPopup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9289);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3365);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_PersonRounded__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(759);
/* harmony import */ var _mui_icons_material_PersonRounded__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PersonRounded__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_LogoutTwoTone__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6927);
/* harmony import */ var _mui_icons_material_LogoutTwoTone__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LogoutTwoTone__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _context_country__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1961);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_icons_material_EditLocationAlt__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7160);
/* harmony import */ var _mui_icons_material_EditLocationAlt__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_EditLocationAlt__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _services_userServices__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(7890);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_countryPopup__WEBPACK_IMPORTED_MODULE_7__, react_toastify__WEBPACK_IMPORTED_MODULE_12__, _context_country__WEBPACK_IMPORTED_MODULE_15__, _services_userServices__WEBPACK_IMPORTED_MODULE_18__]);
([_countryPopup__WEBPACK_IMPORTED_MODULE_7__, react_toastify__WEBPACK_IMPORTED_MODULE_12__, _context_country__WEBPACK_IMPORTED_MODULE_15__, _services_userServices__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











// import {MenuIcon} from 'react-icons/gi';










function navigation({ me  }) {
    const myData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country__WEBPACK_IMPORTED_MODULE_15__/* .Context */ ._);
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_14__.useSession)();
    const [drawerState, setDrawerState] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [cartCount, setCartCount] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(0);
    const [country, setCountry] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(myData.value.country);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (localStorage.getItem("country")) {
            setOpen(false);
        } else {
            setOpen(true);
        }
    }, []);
    const handleClose = ()=>{
        setOpen(false);
    };
    function logOut() {
        (0,next_auth_react__WEBPACK_IMPORTED_MODULE_14__.signOut)();
        react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.success("Logged out successfully!", {
            position: "top-center",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined
        });
    }
    const toggleDrawer = ()=>(event)=>{
            if (event.type === "keydown" && (event.key === "Tab" || event.key === "Shift")) {
                return;
            }
            setDrawerState(!drawerState);
        }
    ;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "navDesktop flex flex-row bg-black py-3.5 text-white",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Container, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-direction:row mx-auto flex items-center justify-between ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: {
                                    width: "200px"
                                },
                                onClick: ()=>setOpen(true)
                                ,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "mb-0",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        children: [
                                            myData.value.country,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_EditLocationAlt__WEBPACK_IMPORTED_MODULE_17___default()), {
                                                style: {
                                                    paddingLeft: "10px",
                                                    fontSize: "28px"
                                                }
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "text-decoration-none text-white",
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: "DISTINGUISHED SOCIETY"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "mb-0",
                                    children: [
                                        session ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                                    href: "../profilePage",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "signUp mx-3 inline",
                                                        children: "My Profile"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                                    href: "../AffiliateProgram",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "signUp ms-2 me-3 inline",
                                                        children: "Become an Affiliate"
                                                    })
                                                })
                                            ]
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                                href: "../AffiliateProgram",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "signUp ms-2 me-3 inline",
                                                    children: "Become an Affiliate"
                                                })
                                            })
                                        }),
                                        session ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "inline",
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiLogOut, {
                                                    onClick: ()=>logOut()
                                                }),
                                                " "
                                            ]
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                        session ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                            href: "../wishList/wishlist",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "mx-3 inline",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4___default()), {})
                                            })
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            onClick: ()=>(0,next_auth_react__WEBPACK_IMPORTED_MODULE_14__.signIn)()
                                            ,
                                            className: "mx-3 inline",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4___default()), {})
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                            href: "../myCart",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "shoppingCartIcon inline",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Badge, {
                                                    badgeContent: cartCount,
                                                    color: "primary",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiShoppingCart, {})
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "navMobile",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Container, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "respMainDiv",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "respNavDiv1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_9___default()), {
                                        className: "hamburger",
                                        onClick: toggleDrawer()
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Drawer, {
                                        anchor: "left",
                                        open: drawerState,
                                        onClose: toggleDrawer(),
                                        className: "navDrawerResp",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Box, {
                                            sx: {
                                                width: 250
                                            },
                                            role: "presentation",
                                            onClick: toggleDrawer(),
                                            onKeyDown: toggleDrawer(),
                                            className: "resNav",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.List, {
                                                children: [
                                                    session ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                                        href: "../profilePage",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItem, {
                                                            disablePadding: true,
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemButton, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PersonRounded__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                                        className: "navIcon"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemText, {
                                                                        primary: "My Profile"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItem, {
                                                        disablePadding: true,
                                                        onClick: ()=>(0,next_auth_react__WEBPACK_IMPORTED_MODULE_14__.signIn)()
                                                        ,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemButton, {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PersonRounded__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                                    className: "navIcon"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemText, {
                                                                    primary: "Sign In"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Divider, {}),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                                        href: "../myCart",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItem, {
                                                            disablePadding: true,
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemButton, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ShoppingCartOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                        className: "navIcon"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemText, {
                                                                        primary: "My Cart"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Divider, {}),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                                        href: "../AffiliateProgram",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItem, {
                                                            disablePadding: true,
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemButton, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_HandshakeOutlined__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                        className: "navIcon"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemText, {
                                                                        primary: "Become an Affiliate"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Divider, {}),
                                                    session ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                                        href: "../wishList/wishlist",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItem, {
                                                            disablePadding: true,
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemButton, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                        className: "navIcon"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemText, {
                                                                        primary: "My Wishlist"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItem, {
                                                        disablePadding: true,
                                                        onClick: ()=>(0,next_auth_react__WEBPACK_IMPORTED_MODULE_14__.signIn)()
                                                        ,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemButton, {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                    className: "navIcon"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemText, {
                                                                    primary: "My Wishlist"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Divider, {}),
                                                    session ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItem, {
                                                        disablePadding: true,
                                                        onClick: ()=>logOut()
                                                        ,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemButton, {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_LogoutTwoTone__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                                    className: "navIcon"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.ListItemText, {
                                                                    primary: "Logout"
                                                                })
                                                            ]
                                                        })
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Divider, {})
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                        href: "/",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "respTitle",
                                            children: "DISTINGUISHED SOCIETY"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "respNavDiv2",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                            href: "../wishList/wishlist",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                className: "mx-3 inline",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4___default()), {}),
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                            href: "../myCart",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "shoppingCartIcon inline",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Badge, {
                                                    badgeContent: cartCount,
                                                    color: "primary",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiShoppingCart, {})
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_countryPopup__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                open: open,
                handleClose: handleClose,
                country: country,
                setCountry: setCountry
            })
        ]
    });
};
async function getServerSideProps(context) {
    const session = await getSession(context);
    try {
        const { me , errors  } = await getProfile(session.id);
        if (errors || !me) {
            return {
                props: {
                    me: []
                }
            };
        }
        return {
            props: {
                me
            }
        };
    } catch (e) {
        return {
            props: {
                me: []
            }
        };
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2867:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ offerImages)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4508);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);


 // requires a loader




function offerImages(props) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const { 0: banners , 1: setBanners  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(props.banners);
    function redirectImage(image) {
        if (image.redirectLink != "#") {
            router.push(image.redirectLink);
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2__.Carousel, {
        autoPlay: true,
        interval: 3000,
        showThumbs: false,
        infiniteLoop: true,
        verticalSwipe: "natural",
        children: banners === null || banners === void 0 ? void 0 : banners.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                onClick: (e)=>redirectImage(image)
                ,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: image.imageLink,
                    className: "offerImages"
                })
            })
        )
    });
};


/***/ }),

/***/ 5745:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ orderHistory)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _orderHistory_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9862);
/* harmony import */ var _orderHistory_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_orderHistory_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);





// import {Invoice} from './invoice';
function orderHistory(props) {
    const { 0: download , 1: setDownload  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    // function downloadInvoid()
    // {
    //     console.log("download")
    //     setDownload(true)
    //     //ReactPDF.render(<MyDocument />, 'downloads/example.pdf');
    // }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
            style: {
                margin: "24px 0px"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_orderHistory_module_css__WEBPACK_IMPORTED_MODULE_4___default().invoiceDiv),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                children: "Placed on: "
                            }),
                            " ",
                            props.data.createdAt.split("T")[0]
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_orderHistory_module_css__WEBPACK_IMPORTED_MODULE_4___default().detailsDiv),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                    children: "Order ID: "
                                }),
                                " ",
                                props.data._id
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_orderHistory_module_css__WEBPACK_IMPORTED_MODULE_4___default().subDiv),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_orderHistory_module_css__WEBPACK_IMPORTED_MODULE_4___default().products),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("b", {
                                                children: [
                                                    "Products : ",
                                                    props.data.products.length
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_orderHistory_module_css__WEBPACK_IMPORTED_MODULE_4___default().imageDiv),
                                            children: props.data.products.map((product, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                    href: `../products/${product.product.slug}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        className: (_orderHistory_module_css__WEBPACK_IMPORTED_MODULE_4___default().productImages),
                                                        src: product.product.images[0]
                                                    })
                                                })
                                            )
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                            children: "Total Amount:"
                                        }),
                                        " ",
                                        props.data.orderAmount,
                                        " ",
                                        "    ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            style: {
                                                color: "green"
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                children: props.data.orderType
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};


/***/ }),

/***/ 9861:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ payment)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9915);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_4__]);
js_cookie__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function payment(props) {
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_5__.useSession)();
    console.log("data", data);
    console.log("session", session);
    const data = {
        address: props.address.address,
        landmark: props.address.landmark,
        state: props.address.state,
        city: props.address.city,
        isInternational: props.address.isInternational,
        pincode: props.address.pincode,
        delivery_country: props.address.delivery_country,
        order_type: props.address.order_type,
        phoneNumber: props.address.phoneNumber
    };
    async function placeOrder() {
        let res;
        var ref;
        res = await axios__WEBPACK_IMPORTED_MODULE_3___default()({
            url: `https://www.thedistinguishedsociety.com/internal/api/users/placeOrder`,
            method: "POST",
            headers: {
                "authorization": (ref = localStorage.getItem("user")) !== null && ref !== void 0 ? ref : ""
            },
            data: data
        });
        if (res.data.status == "success") {} else {}
    }
    async function placeGuestOrder() {
        const guestCart = JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_4__["default"].get("cart"));
        const guestData = {
            ...data,
            guestCart
        };
        console.log("guest data", guestData);
    //   let res;
    //  res = await axios(
    //   {
    //       url: `https://www.thedistinguishedsociety.com/internal/api/users/placeGuestOrder` ,
    //       method: "POST",
    //       headers: {
    //         'authorization' : localStorage.getItem('user') ?? ""
    //           },
    //       data : data
    //   }
    // )
    // if(res.data.status == 'success')
    // {
    // }
    // else
    // {
    // }
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        session ? placeOrder() : placeGuestOrder();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Container, {
        children: "payment"
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7709:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function profileSidebar(props) {
    return /*#__PURE__*/ _jsxs("div", {
        children: [
            /*#__PURE__*/ _jsx("h1", {
                className: "heading profileHeading",
                children: "MY PROFILE"
            }),
            /*#__PURE__*/ _jsxs("ul", {
                children: [
                    /*#__PURE__*/ _jsx("li", {
                        className: `profileList ${props.tab === 0 ? "activeProfileList" : ""}`,
                        onClick: (e)=>props.handleClick(0)
                        ,
                        children: "My details"
                    }),
                    /*#__PURE__*/ _jsx("li", {
                        className: `profileList ${props.tab === 1 ? "activeProfileList" : ""}`,
                        onClick: (e)=>props.handleClick(1)
                        ,
                        children: "My order History"
                    }),
                    /*#__PURE__*/ _jsx("li", {
                        className: `profileList ${props.tab === 2 ? "activeProfileList" : ""}`,
                        onClick: (e)=>props.handleClick(2)
                        ,
                        children: "My address"
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 6765:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ shipmentDetails)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _shipmentDetails_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4126);
/* harmony import */ var _shipmentDetails_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_shipmentDetails_module_css__WEBPACK_IMPORTED_MODULE_3__);




function shipmentDetails(props) {
    const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("Prepaid");
    console.log("props", props);
    function handleChange(e) {
        setValue(e.target.value);
        let newData = {
            ...props.address
        };
        console.log(newData);
        newData["order_type"] = e.target.value;
        console.log("new data after order type", newData);
        props.setAddress(newData);
        props.checkShippingPrice();
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        let newData = {
            ...props.address
        };
        console.log(newData);
        newData["order_type"] = "Prepaid";
        console.log("new data after order type", newData);
        props.setAddress(newData);
        window.scrollTo(0, 0);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Container, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_shipmentDetails_module_css__WEBPACK_IMPORTED_MODULE_3___default().main),
            children: [
                props.address.delivery_country.name == "India" || props.address.delivery_country.name == "india" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_shipmentDetails_module_css__WEBPACK_IMPORTED_MODULE_3___default().freeDelivery),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Radio, {
                            checked: true
                        }),
                        label: "Free Delivery"
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: (_shipmentDetails_module_css__WEBPACK_IMPORTED_MODULE_3___default().subHeadText),
                    children: " Select Payment Method"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.RadioGroup, {
                        "aria-labelledby": "demo-controlled-radio-buttons-group",
                        name: "controlled-radio-buttons-group",
                        value: value,
                        onChange: (e)=>handleChange(e)
                        ,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_shipmentDetails_module_css__WEBPACK_IMPORTED_MODULE_3___default().freeDelivery),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
                                    value: "Prepaid",
                                    control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Radio, {}),
                                    label: "UPI / Debit card / Credit card"
                                })
                            }),
                            props.address.delivery_country == "IN" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_shipmentDetails_module_css__WEBPACK_IMPORTED_MODULE_3___default().freeDelivery),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
                                    value: "COD",
                                    control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Radio, {}),
                                    label: "Cash on delivery"
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 9922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ sizeChart)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4317);
/* harmony import */ var _mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_3__);




function sizeChart(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
        open: props.sizeOpen,
        "aria-labelledby": "responsive-dialog-title",
        onClose: props.handleSizeClose,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_3___default()), {
                className: "formClose",
                onClick: props.handleSizeClose
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Container, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogActions, {
                    className: "loginFormGrid",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        style: {
                            padding: "20px 14px"
                        },
                        src: "../assets/sizeChart.png"
                    })
                })
            })
        ]
    });
};


/***/ }),

/***/ 1961:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ Context),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_userServices__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7890);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_userServices__WEBPACK_IMPORTED_MODULE_3__]);
_services_userServices__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Context = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const ContextProvider = ({ children  })=>{
    const country = "India";
    const currency = "INR";
    const currencyRate = 1;
    const countryCode = "IN";
    var ref, ref1, ref2, ref3;
    let { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        country:  false ? 0 : country,
        currency:  false ? 0 : currency,
        currencyRate:  false ? 0 : currencyRate,
        countryCode:  false ? 0 : countryCode
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        value = {
            country: localStorage.getItem("country"),
            currency: localStorage.getItem("currency"),
            currencyRate: localStorage.getItem("currencyRate"),
            countryCode: localStorage.getItem("countryCode")
        };
    });
    const exposed = {
        value,
        setValue
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Context.Provider, {
        value: exposed,
        children: children
    });
};
// export const useUser = () => useContext(Context);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContextProvider);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ convertCurrency)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

var api_key = "mccTNQrgj34is5qhmrkzeasD9ZZsqkW9";
async function convertCurrency(convertTo) {
    let response;
    let error;
    try {
        let result = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`https://api.exchangerate.host/convert?to=${convertTo}&from=INR&amount=1`);
        if (result.data.status === "error") {
            return {
                response,
                error: "An error occurred."
            };
        }
        response = result.data.result;
        localStorage.setItem("currencyRate", response);
        localStorage.setItem("currency", convertTo);
        return {
            response,
            error
        };
    } catch (e) {
        error = e.message;
        return {
            response,
            error
        };
    }
}


/***/ }),

/***/ 193:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ countries)
/* harmony export */ });
const countries = [
    {
        "countryCode": "AD",
        "countryName": "Andorra",
        "currencyCode": "EUR",
        "population": "84000",
        "capital": "Andorra la Vella",
        "continentName": "Europe"
    },
    {
        "countryCode": "AE",
        "countryName": "United Arab Emirates",
        "currencyCode": "AED",
        "population": "4975593",
        "capital": "Abu Dhabi",
        "continentName": "Asia"
    },
    {
        "countryCode": "AF",
        "countryName": "Afghanistan",
        "currencyCode": "AFN",
        "population": "29121286",
        "capital": "Kabul",
        "continentName": "Asia"
    },
    {
        "countryCode": "AG",
        "countryName": "Antigua and Barbuda",
        "currencyCode": "XCD",
        "population": "86754",
        "capital": "St. John's",
        "continentName": "North America"
    },
    {
        "countryCode": "AI",
        "countryName": "Anguilla",
        "currencyCode": "XCD",
        "population": "13254",
        "capital": "The Valley",
        "continentName": "North America"
    },
    {
        "countryCode": "AL",
        "countryName": "Albania",
        "currencyCode": "ALL",
        "population": "2986952",
        "capital": "Tirana",
        "continentName": "Europe"
    },
    {
        "countryCode": "AM",
        "countryName": "Armenia",
        "currencyCode": "AMD",
        "population": "2968000",
        "capital": "Yerevan",
        "continentName": "Asia"
    },
    {
        "countryCode": "AO",
        "countryName": "Angola",
        "currencyCode": "AOA",
        "population": "13068161",
        "capital": "Luanda",
        "continentName": "Africa"
    },
    {
        "countryCode": "AQ",
        "countryName": "Antarctica",
        "currencyCode": "",
        "population": "0",
        "capital": "",
        "continentName": "Antarctica"
    },
    {
        "countryCode": "AR",
        "countryName": "Argentina",
        "currencyCode": "ARS",
        "population": "41343201",
        "capital": "Buenos Aires",
        "continentName": "South America"
    },
    {
        "countryCode": "AS",
        "countryName": "American Samoa",
        "currencyCode": "USD",
        "population": "57881",
        "capital": "Pago Pago",
        "continentName": "Oceania"
    },
    {
        "countryCode": "AT",
        "countryName": "Austria",
        "currencyCode": "EUR",
        "population": "8205000",
        "capital": "Vienna",
        "continentName": "Europe"
    },
    {
        "countryCode": "AU",
        "countryName": "Australia",
        "currencyCode": "AUD",
        "population": "21515754",
        "capital": "Canberra",
        "continentName": "Oceania"
    },
    {
        "countryCode": "AW",
        "countryName": "Aruba",
        "currencyCode": "AWG",
        "population": "71566",
        "capital": "Oranjestad",
        "continentName": "North America"
    },
    {
        "countryCode": "AX",
        "countryName": "\xc5land",
        "currencyCode": "EUR",
        "population": "26711",
        "capital": "Mariehamn",
        "continentName": "Europe"
    },
    {
        "countryCode": "AZ",
        "countryName": "Azerbaijan",
        "currencyCode": "AZN",
        "population": "8303512",
        "capital": "Baku",
        "continentName": "Asia"
    },
    {
        "countryCode": "BA",
        "countryName": "Bosnia and Herzegovina",
        "currencyCode": "BAM",
        "population": "4590000",
        "capital": "Sarajevo",
        "continentName": "Europe"
    },
    {
        "countryCode": "BB",
        "countryName": "Barbados",
        "currencyCode": "BBD",
        "population": "285653",
        "capital": "Bridgetown",
        "continentName": "North America"
    },
    {
        "countryCode": "BD",
        "countryName": "Bangladesh",
        "currencyCode": "BDT",
        "population": "156118464",
        "capital": "Dhaka",
        "continentName": "Asia"
    },
    {
        "countryCode": "BE",
        "countryName": "Belgium",
        "currencyCode": "EUR",
        "population": "10403000",
        "capital": "Brussels",
        "continentName": "Europe"
    },
    {
        "countryCode": "BF",
        "countryName": "Burkina Faso",
        "currencyCode": "XOF",
        "population": "16241811",
        "capital": "Ouagadougou",
        "continentName": "Africa"
    },
    {
        "countryCode": "BG",
        "countryName": "Bulgaria",
        "currencyCode": "BGN",
        "population": "7148785",
        "capital": "Sofia",
        "continentName": "Europe"
    },
    {
        "countryCode": "BH",
        "countryName": "Bahrain",
        "currencyCode": "BHD",
        "population": "738004",
        "capital": "Manama",
        "continentName": "Asia"
    },
    {
        "countryCode": "BI",
        "countryName": "Burundi",
        "currencyCode": "BIF",
        "population": "9863117",
        "capital": "Bujumbura",
        "continentName": "Africa"
    },
    {
        "countryCode": "BJ",
        "countryName": "Benin",
        "currencyCode": "XOF",
        "population": "9056010",
        "capital": "Porto-Novo",
        "continentName": "Africa"
    },
    {
        "countryCode": "BL",
        "countryName": "Saint Barth\xe9lemy",
        "currencyCode": "EUR",
        "population": "8450",
        "capital": "Gustavia",
        "continentName": "North America"
    },
    {
        "countryCode": "BM",
        "countryName": "Bermuda",
        "currencyCode": "BMD",
        "population": "65365",
        "capital": "Hamilton",
        "continentName": "North America"
    },
    {
        "countryCode": "BN",
        "countryName": "Brunei",
        "currencyCode": "BND",
        "population": "395027",
        "capital": "Bandar Seri Begawan",
        "continentName": "Asia"
    },
    {
        "countryCode": "BO",
        "countryName": "Bolivia",
        "currencyCode": "BOB",
        "population": "9947418",
        "capital": "Sucre",
        "continentName": "South America"
    },
    {
        "countryCode": "BQ",
        "countryName": "Bonaire",
        "currencyCode": "USD",
        "population": "18012",
        "capital": "Kralendijk",
        "continentName": "North America"
    },
    {
        "countryCode": "BR",
        "countryName": "Brazil",
        "currencyCode": "BRL",
        "population": "201103330",
        "capital": "Bras\xedlia",
        "continentName": "South America"
    },
    {
        "countryCode": "BS",
        "countryName": "Bahamas",
        "currencyCode": "BSD",
        "population": "301790",
        "capital": "Nassau",
        "continentName": "North America"
    },
    {
        "countryCode": "BT",
        "countryName": "Bhutan",
        "currencyCode": "BTN",
        "population": "699847",
        "capital": "Thimphu",
        "continentName": "Asia"
    },
    {
        "countryCode": "BV",
        "countryName": "Bouvet Island",
        "currencyCode": "NOK",
        "population": "0",
        "capital": "",
        "continentName": "Antarctica"
    },
    {
        "countryCode": "BW",
        "countryName": "Botswana",
        "currencyCode": "BWP",
        "population": "2029307",
        "capital": "Gaborone",
        "continentName": "Africa"
    },
    {
        "countryCode": "BY",
        "countryName": "Belarus",
        "currencyCode": "BYR",
        "population": "9685000",
        "capital": "Minsk",
        "continentName": "Europe"
    },
    {
        "countryCode": "BZ",
        "countryName": "Belize",
        "currencyCode": "BZD",
        "population": "314522",
        "capital": "Belmopan",
        "continentName": "North America"
    },
    {
        "countryCode": "CA",
        "countryName": "Canada",
        "currencyCode": "CAD",
        "population": "33679000",
        "capital": "Ottawa",
        "continentName": "North America"
    },
    {
        "countryCode": "CC",
        "countryName": "Cocos [Keeling] Islands",
        "currencyCode": "AUD",
        "population": "628",
        "capital": "West Island",
        "continentName": "Asia"
    },
    {
        "countryCode": "CD",
        "countryName": "Democratic Republic of the Congo",
        "currencyCode": "CDF",
        "population": "70916439",
        "capital": "Kinshasa",
        "continentName": "Africa"
    },
    {
        "countryCode": "CF",
        "countryName": "Central African Republic",
        "currencyCode": "XAF",
        "population": "4844927",
        "capital": "Bangui",
        "continentName": "Africa"
    },
    {
        "countryCode": "CG",
        "countryName": "Republic of the Congo",
        "currencyCode": "XAF",
        "population": "3039126",
        "capital": "Brazzaville",
        "continentName": "Africa"
    },
    {
        "countryCode": "CH",
        "countryName": "Switzerland",
        "currencyCode": "CHF",
        "population": "7581000",
        "capital": "Bern",
        "continentName": "Europe"
    },
    {
        "countryCode": "CI",
        "countryName": "Ivory Coast",
        "currencyCode": "XOF",
        "population": "21058798",
        "capital": "Yamoussoukro",
        "continentName": "Africa"
    },
    {
        "countryCode": "CK",
        "countryName": "Cook Islands",
        "currencyCode": "NZD",
        "population": "21388",
        "capital": "Avarua",
        "continentName": "Oceania"
    },
    {
        "countryCode": "CL",
        "countryName": "Chile",
        "currencyCode": "CLP",
        "population": "16746491",
        "capital": "Santiago",
        "continentName": "South America"
    },
    {
        "countryCode": "CM",
        "countryName": "Cameroon",
        "currencyCode": "XAF",
        "population": "19294149",
        "capital": "Yaound\xe9",
        "continentName": "Africa"
    },
    {
        "countryCode": "CN",
        "countryName": "China",
        "currencyCode": "CNY",
        "population": "1330044000",
        "capital": "Beijing",
        "continentName": "Asia"
    },
    {
        "countryCode": "CO",
        "countryName": "Colombia",
        "currencyCode": "COP",
        "population": "47790000",
        "capital": "Bogot\xe1",
        "continentName": "South America"
    },
    {
        "countryCode": "CR",
        "countryName": "Costa Rica",
        "currencyCode": "CRC",
        "population": "4516220",
        "capital": "San Jos\xe9",
        "continentName": "North America"
    },
    {
        "countryCode": "CU",
        "countryName": "Cuba",
        "currencyCode": "CUP",
        "population": "11423000",
        "capital": "Havana",
        "continentName": "North America"
    },
    {
        "countryCode": "CV",
        "countryName": "Cape Verde",
        "currencyCode": "CVE",
        "population": "508659",
        "capital": "Praia",
        "continentName": "Africa"
    },
    {
        "countryCode": "CW",
        "countryName": "Curacao",
        "currencyCode": "ANG",
        "population": "141766",
        "capital": "Willemstad",
        "continentName": "North America"
    },
    {
        "countryCode": "CX",
        "countryName": "Christmas Island",
        "currencyCode": "AUD",
        "population": "1500",
        "capital": "Flying Fish Cove",
        "continentName": "Asia"
    },
    {
        "countryCode": "CY",
        "countryName": "Cyprus",
        "currencyCode": "EUR",
        "population": "1102677",
        "capital": "Nicosia",
        "continentName": "Europe"
    },
    {
        "countryCode": "CZ",
        "countryName": "Czechia",
        "currencyCode": "CZK",
        "population": "10476000",
        "capital": "Prague",
        "continentName": "Europe"
    },
    {
        "countryCode": "DE",
        "countryName": "Germany",
        "currencyCode": "EUR",
        "population": "81802257",
        "capital": "Berlin",
        "continentName": "Europe"
    },
    {
        "countryCode": "DJ",
        "countryName": "Djibouti",
        "currencyCode": "DJF",
        "population": "740528",
        "capital": "Djibouti",
        "continentName": "Africa"
    },
    {
        "countryCode": "DK",
        "countryName": "Denmark",
        "currencyCode": "DKK",
        "population": "5484000",
        "capital": "Copenhagen",
        "continentName": "Europe"
    },
    {
        "countryCode": "DM",
        "countryName": "Dominica",
        "currencyCode": "XCD",
        "population": "72813",
        "capital": "Roseau",
        "continentName": "North America"
    },
    {
        "countryCode": "DO",
        "countryName": "Dominican Republic",
        "currencyCode": "DOP",
        "population": "9823821",
        "capital": "Santo Domingo",
        "continentName": "North America"
    },
    {
        "countryCode": "DZ",
        "countryName": "Algeria",
        "currencyCode": "DZD",
        "population": "34586184",
        "capital": "Algiers",
        "continentName": "Africa"
    },
    {
        "countryCode": "EC",
        "countryName": "Ecuador",
        "currencyCode": "USD",
        "population": "14790608",
        "capital": "Quito",
        "continentName": "South America"
    },
    {
        "countryCode": "EE",
        "countryName": "Estonia",
        "currencyCode": "EUR",
        "population": "1291170",
        "capital": "Tallinn",
        "continentName": "Europe"
    },
    {
        "countryCode": "EG",
        "countryName": "Egypt",
        "currencyCode": "EGP",
        "population": "80471869",
        "capital": "Cairo",
        "continentName": "Africa"
    },
    {
        "countryCode": "EH",
        "countryName": "Western Sahara",
        "currencyCode": "MAD",
        "population": "273008",
        "capital": "La\xe2youne / El Aai\xfan",
        "continentName": "Africa"
    },
    {
        "countryCode": "ER",
        "countryName": "Eritrea",
        "currencyCode": "ERN",
        "population": "5792984",
        "capital": "Asmara",
        "continentName": "Africa"
    },
    {
        "countryCode": "ES",
        "countryName": "Spain",
        "currencyCode": "EUR",
        "population": "46505963",
        "capital": "Madrid",
        "continentName": "Europe"
    },
    {
        "countryCode": "ET",
        "countryName": "Ethiopia",
        "currencyCode": "ETB",
        "population": "88013491",
        "capital": "Addis Ababa",
        "continentName": "Africa"
    },
    {
        "countryCode": "FI",
        "countryName": "Finland",
        "currencyCode": "EUR",
        "population": "5244000",
        "capital": "Helsinki",
        "continentName": "Europe"
    },
    {
        "countryCode": "FJ",
        "countryName": "Fiji",
        "currencyCode": "FJD",
        "population": "875983",
        "capital": "Suva",
        "continentName": "Oceania"
    },
    {
        "countryCode": "FK",
        "countryName": "Falkland Islands",
        "currencyCode": "FKP",
        "population": "2638",
        "capital": "Stanley",
        "continentName": "South America"
    },
    {
        "countryCode": "FM",
        "countryName": "Micronesia",
        "currencyCode": "USD",
        "population": "107708",
        "capital": "Palikir",
        "continentName": "Oceania"
    },
    {
        "countryCode": "FO",
        "countryName": "Faroe Islands",
        "currencyCode": "DKK",
        "population": "48228",
        "capital": "T\xf3rshavn",
        "continentName": "Europe"
    },
    {
        "countryCode": "FR",
        "countryName": "France",
        "currencyCode": "EUR",
        "population": "64768389",
        "capital": "Paris",
        "continentName": "Europe"
    },
    {
        "countryCode": "GA",
        "countryName": "Gabon",
        "currencyCode": "XAF",
        "population": "1545255",
        "capital": "Libreville",
        "continentName": "Africa"
    },
    {
        "countryCode": "GB",
        "countryName": "United Kingdom",
        "currencyCode": "GBP",
        "population": "62348447",
        "capital": "London",
        "continentName": "Europe"
    },
    {
        "countryCode": "GD",
        "countryName": "Grenada",
        "currencyCode": "XCD",
        "population": "107818",
        "capital": "St. George's",
        "continentName": "North America"
    },
    {
        "countryCode": "GE",
        "countryName": "Georgia",
        "currencyCode": "GEL",
        "population": "4630000",
        "capital": "Tbilisi",
        "continentName": "Asia"
    },
    {
        "countryCode": "GF",
        "countryName": "French Guiana",
        "currencyCode": "EUR",
        "population": "195506",
        "capital": "Cayenne",
        "continentName": "South America"
    },
    {
        "countryCode": "GG",
        "countryName": "Guernsey",
        "currencyCode": "GBP",
        "population": "65228",
        "capital": "St Peter Port",
        "continentName": "Europe"
    },
    {
        "countryCode": "GH",
        "countryName": "Ghana",
        "currencyCode": "GHS",
        "population": "24339838",
        "capital": "Accra",
        "continentName": "Africa"
    },
    {
        "countryCode": "GI",
        "countryName": "Gibraltar",
        "currencyCode": "GIP",
        "population": "27884",
        "capital": "Gibraltar",
        "continentName": "Europe"
    },
    {
        "countryCode": "GL",
        "countryName": "Greenland",
        "currencyCode": "DKK",
        "population": "56375",
        "capital": "Nuuk",
        "continentName": "North America"
    },
    {
        "countryCode": "GM",
        "countryName": "Gambia",
        "currencyCode": "GMD",
        "population": "1593256",
        "capital": "Bathurst",
        "continentName": "Africa"
    },
    {
        "countryCode": "GN",
        "countryName": "Guinea",
        "currencyCode": "GNF",
        "population": "10324025",
        "capital": "Conakry",
        "continentName": "Africa"
    },
    {
        "countryCode": "GP",
        "countryName": "Guadeloupe",
        "currencyCode": "EUR",
        "population": "443000",
        "capital": "Basse-Terre",
        "continentName": "North America"
    },
    {
        "countryCode": "GQ",
        "countryName": "Equatorial Guinea",
        "currencyCode": "XAF",
        "population": "1014999",
        "capital": "Malabo",
        "continentName": "Africa"
    },
    {
        "countryCode": "GR",
        "countryName": "Greece",
        "currencyCode": "EUR",
        "population": "11000000",
        "capital": "Athens",
        "continentName": "Europe"
    },
    {
        "countryCode": "GS",
        "countryName": "South Georgia and the South Sandwich Islands",
        "currencyCode": "GBP",
        "population": "30",
        "capital": "Grytviken",
        "continentName": "Antarctica"
    },
    {
        "countryCode": "GT",
        "countryName": "Guatemala",
        "currencyCode": "GTQ",
        "population": "13550440",
        "capital": "Guatemala City",
        "continentName": "North America"
    },
    {
        "countryCode": "GU",
        "countryName": "Guam",
        "currencyCode": "USD",
        "population": "159358",
        "capital": "Hag\xe5t\xf1a",
        "continentName": "Oceania"
    },
    {
        "countryCode": "GW",
        "countryName": "Guinea-Bissau",
        "currencyCode": "XOF",
        "population": "1565126",
        "capital": "Bissau",
        "continentName": "Africa"
    },
    {
        "countryCode": "GY",
        "countryName": "Guyana",
        "currencyCode": "GYD",
        "population": "748486",
        "capital": "Georgetown",
        "continentName": "South America"
    },
    {
        "countryCode": "HK",
        "countryName": "Hong Kong",
        "currencyCode": "HKD",
        "population": "6898686",
        "capital": "Hong Kong",
        "continentName": "Asia"
    },
    {
        "countryCode": "HM",
        "countryName": "Heard Island and McDonald Islands",
        "currencyCode": "AUD",
        "population": "0",
        "capital": "",
        "continentName": "Antarctica"
    },
    {
        "countryCode": "HN",
        "countryName": "Honduras",
        "currencyCode": "HNL",
        "population": "7989415",
        "capital": "Tegucigalpa",
        "continentName": "North America"
    },
    {
        "countryCode": "HR",
        "countryName": "Croatia",
        "currencyCode": "HRK",
        "population": "4284889",
        "capital": "Zagreb",
        "continentName": "Europe"
    },
    {
        "countryCode": "HT",
        "countryName": "Haiti",
        "currencyCode": "HTG",
        "population": "9648924",
        "capital": "Port-au-Prince",
        "continentName": "North America"
    },
    {
        "countryCode": "HU",
        "countryName": "Hungary",
        "currencyCode": "HUF",
        "population": "9982000",
        "capital": "Budapest",
        "continentName": "Europe"
    },
    {
        "countryCode": "ID",
        "countryName": "Indonesia",
        "currencyCode": "IDR",
        "population": "242968342",
        "capital": "Jakarta",
        "continentName": "Asia"
    },
    {
        "countryCode": "IE",
        "countryName": "Ireland",
        "currencyCode": "EUR",
        "population": "4622917",
        "capital": "Dublin",
        "continentName": "Europe"
    },
    {
        "countryCode": "IL",
        "countryName": "Israel",
        "currencyCode": "ILS",
        "population": "7353985",
        "capital": "",
        "continentName": "Asia"
    },
    {
        "countryCode": "IM",
        "countryName": "Isle of Man",
        "currencyCode": "GBP",
        "population": "75049",
        "capital": "Douglas",
        "continentName": "Europe"
    },
    {
        "countryCode": "IN",
        "countryName": "India",
        "currencyCode": "INR",
        "population": "1173108018",
        "capital": "New Delhi",
        "continentName": "Asia"
    },
    {
        "countryCode": "IO",
        "countryName": "British Indian Ocean Territory",
        "currencyCode": "USD",
        "population": "4000",
        "capital": "",
        "continentName": "Asia"
    },
    {
        "countryCode": "IQ",
        "countryName": "Iraq",
        "currencyCode": "IQD",
        "population": "29671605",
        "capital": "Baghdad",
        "continentName": "Asia"
    },
    {
        "countryCode": "IR",
        "countryName": "Iran",
        "currencyCode": "IRR",
        "population": "76923300",
        "capital": "Tehran",
        "continentName": "Asia"
    },
    {
        "countryCode": "IS",
        "countryName": "Iceland",
        "currencyCode": "ISK",
        "population": "308910",
        "capital": "Reykjavik",
        "continentName": "Europe"
    },
    {
        "countryCode": "IT",
        "countryName": "Italy",
        "currencyCode": "EUR",
        "population": "60340328",
        "capital": "Rome",
        "continentName": "Europe"
    },
    {
        "countryCode": "JE",
        "countryName": "Jersey",
        "currencyCode": "GBP",
        "population": "90812",
        "capital": "Saint Helier",
        "continentName": "Europe"
    },
    {
        "countryCode": "JM",
        "countryName": "Jamaica",
        "currencyCode": "JMD",
        "population": "2847232",
        "capital": "Kingston",
        "continentName": "North America"
    },
    {
        "countryCode": "JO",
        "countryName": "Jordan",
        "currencyCode": "JOD",
        "population": "6407085",
        "capital": "Amman",
        "continentName": "Asia"
    },
    {
        "countryCode": "JP",
        "countryName": "Japan",
        "currencyCode": "JPY",
        "population": "127288000",
        "capital": "Tokyo",
        "continentName": "Asia"
    },
    {
        "countryCode": "KE",
        "countryName": "Kenya",
        "currencyCode": "KES",
        "population": "40046566",
        "capital": "Nairobi",
        "continentName": "Africa"
    },
    {
        "countryCode": "KG",
        "countryName": "Kyrgyzstan",
        "currencyCode": "KGS",
        "population": "5776500",
        "capital": "Bishkek",
        "continentName": "Asia"
    },
    {
        "countryCode": "KH",
        "countryName": "Cambodia",
        "currencyCode": "KHR",
        "population": "14453680",
        "capital": "Phnom Penh",
        "continentName": "Asia"
    },
    {
        "countryCode": "KI",
        "countryName": "Kiribati",
        "currencyCode": "AUD",
        "population": "92533",
        "capital": "Tarawa",
        "continentName": "Oceania"
    },
    {
        "countryCode": "KM",
        "countryName": "Comoros",
        "currencyCode": "KMF",
        "population": "773407",
        "capital": "Moroni",
        "continentName": "Africa"
    },
    {
        "countryCode": "KN",
        "countryName": "Saint Kitts and Nevis",
        "currencyCode": "XCD",
        "population": "51134",
        "capital": "Basseterre",
        "continentName": "North America"
    },
    {
        "countryCode": "KP",
        "countryName": "North Korea",
        "currencyCode": "KPW",
        "population": "22912177",
        "capital": "Pyongyang",
        "continentName": "Asia"
    },
    {
        "countryCode": "KR",
        "countryName": "South Korea",
        "currencyCode": "KRW",
        "population": "48422644",
        "capital": "Seoul",
        "continentName": "Asia"
    },
    {
        "countryCode": "KW",
        "countryName": "Kuwait",
        "currencyCode": "KWD",
        "population": "2789132",
        "capital": "Kuwait City",
        "continentName": "Asia"
    },
    {
        "countryCode": "KY",
        "countryName": "Cayman Islands",
        "currencyCode": "KYD",
        "population": "44270",
        "capital": "George Town",
        "continentName": "North America"
    },
    {
        "countryCode": "KZ",
        "countryName": "Kazakhstan",
        "currencyCode": "KZT",
        "population": "15340000",
        "capital": "Astana",
        "continentName": "Asia"
    },
    {
        "countryCode": "LA",
        "countryName": "Laos",
        "currencyCode": "LAK",
        "population": "6368162",
        "capital": "Vientiane",
        "continentName": "Asia"
    },
    {
        "countryCode": "LB",
        "countryName": "Lebanon",
        "currencyCode": "LBP",
        "population": "4125247",
        "capital": "Beirut",
        "continentName": "Asia"
    },
    {
        "countryCode": "LC",
        "countryName": "Saint Lucia",
        "currencyCode": "XCD",
        "population": "160922",
        "capital": "Castries",
        "continentName": "North America"
    },
    {
        "countryCode": "LI",
        "countryName": "Liechtenstein",
        "currencyCode": "CHF",
        "population": "35000",
        "capital": "Vaduz",
        "continentName": "Europe"
    },
    {
        "countryCode": "LK",
        "countryName": "Sri Lanka",
        "currencyCode": "LKR",
        "population": "21513990",
        "capital": "Colombo",
        "continentName": "Asia"
    },
    {
        "countryCode": "LR",
        "countryName": "Liberia",
        "currencyCode": "LRD",
        "population": "3685076",
        "capital": "Monrovia",
        "continentName": "Africa"
    },
    {
        "countryCode": "LS",
        "countryName": "Lesotho",
        "currencyCode": "LSL",
        "population": "1919552",
        "capital": "Maseru",
        "continentName": "Africa"
    },
    {
        "countryCode": "LT",
        "countryName": "Lithuania",
        "currencyCode": "EUR",
        "population": "2944459",
        "capital": "Vilnius",
        "continentName": "Europe"
    },
    {
        "countryCode": "LU",
        "countryName": "Luxembourg",
        "currencyCode": "EUR",
        "population": "497538",
        "capital": "Luxembourg",
        "continentName": "Europe"
    },
    {
        "countryCode": "LV",
        "countryName": "Latvia",
        "currencyCode": "EUR",
        "population": "2217969",
        "capital": "Riga",
        "continentName": "Europe"
    },
    {
        "countryCode": "LY",
        "countryName": "Libya",
        "currencyCode": "LYD",
        "population": "6461454",
        "capital": "Tripoli",
        "continentName": "Africa"
    },
    {
        "countryCode": "MA",
        "countryName": "Morocco",
        "currencyCode": "MAD",
        "population": "33848242",
        "capital": "Rabat",
        "continentName": "Africa"
    },
    {
        "countryCode": "MC",
        "countryName": "Monaco",
        "currencyCode": "EUR",
        "population": "32965",
        "capital": "Monaco",
        "continentName": "Europe"
    },
    {
        "countryCode": "MD",
        "countryName": "Moldova",
        "currencyCode": "MDL",
        "population": "4324000",
        "capital": "Chi\u015Fin\u0103u",
        "continentName": "Europe"
    },
    {
        "countryCode": "ME",
        "countryName": "Montenegro",
        "currencyCode": "EUR",
        "population": "666730",
        "capital": "Podgorica",
        "continentName": "Europe"
    },
    {
        "countryCode": "MF",
        "countryName": "Saint Martin",
        "currencyCode": "EUR",
        "population": "35925",
        "capital": "Marigot",
        "continentName": "North America"
    },
    {
        "countryCode": "MG",
        "countryName": "Madagascar",
        "currencyCode": "MGA",
        "population": "21281844",
        "capital": "Antananarivo",
        "continentName": "Africa"
    },
    {
        "countryCode": "MH",
        "countryName": "Marshall Islands",
        "currencyCode": "USD",
        "population": "65859",
        "capital": "Majuro",
        "continentName": "Oceania"
    },
    {
        "countryCode": "MK",
        "countryName": "Macedonia",
        "currencyCode": "MKD",
        "population": "2062294",
        "capital": "Skopje",
        "continentName": "Europe"
    },
    {
        "countryCode": "ML",
        "countryName": "Mali",
        "currencyCode": "XOF",
        "population": "13796354",
        "capital": "Bamako",
        "continentName": "Africa"
    },
    {
        "countryCode": "MM",
        "countryName": "Myanmar [Burma]",
        "currencyCode": "MMK",
        "population": "53414374",
        "capital": "Naypyitaw",
        "continentName": "Asia"
    },
    {
        "countryCode": "MN",
        "countryName": "Mongolia",
        "currencyCode": "MNT",
        "population": "3086918",
        "capital": "Ulan Bator",
        "continentName": "Asia"
    },
    {
        "countryCode": "MO",
        "countryName": "Macao",
        "currencyCode": "MOP",
        "population": "449198",
        "capital": "Macao",
        "continentName": "Asia"
    },
    {
        "countryCode": "MP",
        "countryName": "Northern Mariana Islands",
        "currencyCode": "USD",
        "population": "53883",
        "capital": "Saipan",
        "continentName": "Oceania"
    },
    {
        "countryCode": "MQ",
        "countryName": "Martinique",
        "currencyCode": "EUR",
        "population": "432900",
        "capital": "Fort-de-France",
        "continentName": "North America"
    },
    {
        "countryCode": "MR",
        "countryName": "Mauritania",
        "currencyCode": "MRO",
        "population": "3205060",
        "capital": "Nouakchott",
        "continentName": "Africa"
    },
    {
        "countryCode": "MS",
        "countryName": "Montserrat",
        "currencyCode": "XCD",
        "population": "9341",
        "capital": "Plymouth",
        "continentName": "North America"
    },
    {
        "countryCode": "MT",
        "countryName": "Malta",
        "currencyCode": "EUR",
        "population": "403000",
        "capital": "Valletta",
        "continentName": "Europe"
    },
    {
        "countryCode": "MU",
        "countryName": "Mauritius",
        "currencyCode": "MUR",
        "population": "1294104",
        "capital": "Port Louis",
        "continentName": "Africa"
    },
    {
        "countryCode": "MV",
        "countryName": "Maldives",
        "currencyCode": "MVR",
        "population": "395650",
        "capital": "Mal\xe9",
        "continentName": "Asia"
    },
    {
        "countryCode": "MW",
        "countryName": "Malawi",
        "currencyCode": "MWK",
        "population": "15447500",
        "capital": "Lilongwe",
        "continentName": "Africa"
    },
    {
        "countryCode": "MX",
        "countryName": "Mexico",
        "currencyCode": "MXN",
        "population": "112468855",
        "capital": "Mexico City",
        "continentName": "North America"
    },
    {
        "countryCode": "MY",
        "countryName": "Malaysia",
        "currencyCode": "MYR",
        "population": "28274729",
        "capital": "Kuala Lumpur",
        "continentName": "Asia"
    },
    {
        "countryCode": "MZ",
        "countryName": "Mozambique",
        "currencyCode": "MZN",
        "population": "22061451",
        "capital": "Maputo",
        "continentName": "Africa"
    },
    {
        "countryCode": "NA",
        "countryName": "Namibia",
        "currencyCode": "NAD",
        "population": "2128471",
        "capital": "Windhoek",
        "continentName": "Africa"
    },
    {
        "countryCode": "NC",
        "countryName": "New Caledonia",
        "currencyCode": "XPF",
        "population": "216494",
        "capital": "Noumea",
        "continentName": "Oceania"
    },
    {
        "countryCode": "NE",
        "countryName": "Niger",
        "currencyCode": "XOF",
        "population": "15878271",
        "capital": "Niamey",
        "continentName": "Africa"
    },
    {
        "countryCode": "NF",
        "countryName": "Norfolk Island",
        "currencyCode": "AUD",
        "population": "1828",
        "capital": "Kingston",
        "continentName": "Oceania"
    },
    {
        "countryCode": "NG",
        "countryName": "Nigeria",
        "currencyCode": "NGN",
        "population": "154000000",
        "capital": "Abuja",
        "continentName": "Africa"
    },
    {
        "countryCode": "NI",
        "countryName": "Nicaragua",
        "currencyCode": "NIO",
        "population": "5995928",
        "capital": "Managua",
        "continentName": "North America"
    },
    {
        "countryCode": "NL",
        "countryName": "Netherlands",
        "currencyCode": "EUR",
        "population": "16645000",
        "capital": "Amsterdam",
        "continentName": "Europe"
    },
    {
        "countryCode": "NO",
        "countryName": "Norway",
        "currencyCode": "NOK",
        "population": "5009150",
        "capital": "Oslo",
        "continentName": "Europe"
    },
    {
        "countryCode": "NP",
        "countryName": "Nepal",
        "currencyCode": "NPR",
        "population": "28951852",
        "capital": "Kathmandu",
        "continentName": "Asia"
    },
    {
        "countryCode": "NR",
        "countryName": "Nauru",
        "currencyCode": "AUD",
        "population": "10065",
        "capital": "Yaren",
        "continentName": "Oceania"
    },
    {
        "countryCode": "NU",
        "countryName": "Niue",
        "currencyCode": "NZD",
        "population": "2166",
        "capital": "Alofi",
        "continentName": "Oceania"
    },
    {
        "countryCode": "NZ",
        "countryName": "New Zealand",
        "currencyCode": "NZD",
        "population": "4252277",
        "capital": "Wellington",
        "continentName": "Oceania"
    },
    {
        "countryCode": "OM",
        "countryName": "Oman",
        "currencyCode": "OMR",
        "population": "2967717",
        "capital": "Muscat",
        "continentName": "Asia"
    },
    {
        "countryCode": "PA",
        "countryName": "Panama",
        "currencyCode": "PAB",
        "population": "3410676",
        "capital": "Panama City",
        "continentName": "North America"
    },
    {
        "countryCode": "PE",
        "countryName": "Peru",
        "currencyCode": "PEN",
        "population": "29907003",
        "capital": "Lima",
        "continentName": "South America"
    },
    {
        "countryCode": "PF",
        "countryName": "French Polynesia",
        "currencyCode": "XPF",
        "population": "270485",
        "capital": "Papeete",
        "continentName": "Oceania"
    },
    {
        "countryCode": "PG",
        "countryName": "Papua New Guinea",
        "currencyCode": "PGK",
        "population": "6064515",
        "capital": "Port Moresby",
        "continentName": "Oceania"
    },
    {
        "countryCode": "PH",
        "countryName": "Philippines",
        "currencyCode": "PHP",
        "population": "99900177",
        "capital": "Manila",
        "continentName": "Asia"
    },
    {
        "countryCode": "PK",
        "countryName": "Pakistan",
        "currencyCode": "PKR",
        "population": "184404791",
        "capital": "Islamabad",
        "continentName": "Asia"
    },
    {
        "countryCode": "PL",
        "countryName": "Poland",
        "currencyCode": "PLN",
        "population": "38500000",
        "capital": "Warsaw",
        "continentName": "Europe"
    },
    {
        "countryCode": "PM",
        "countryName": "Saint Pierre and Miquelon",
        "currencyCode": "EUR",
        "population": "7012",
        "capital": "Saint-Pierre",
        "continentName": "North America"
    },
    {
        "countryCode": "PN",
        "countryName": "Pitcairn Islands",
        "currencyCode": "NZD",
        "population": "46",
        "capital": "Adamstown",
        "continentName": "Oceania"
    },
    {
        "countryCode": "PR",
        "countryName": "Puerto Rico",
        "currencyCode": "USD",
        "population": "3916632",
        "capital": "San Juan",
        "continentName": "North America"
    },
    {
        "countryCode": "PS",
        "countryName": "Palestine",
        "currencyCode": "ILS",
        "population": "3800000",
        "capital": "",
        "continentName": "Asia"
    },
    {
        "countryCode": "PT",
        "countryName": "Portugal",
        "currencyCode": "EUR",
        "population": "10676000",
        "capital": "Lisbon",
        "continentName": "Europe"
    },
    {
        "countryCode": "PW",
        "countryName": "Palau",
        "currencyCode": "USD",
        "population": "19907",
        "capital": "Melekeok",
        "continentName": "Oceania"
    },
    {
        "countryCode": "PY",
        "countryName": "Paraguay",
        "currencyCode": "PYG",
        "population": "6375830",
        "capital": "Asunci\xf3n",
        "continentName": "South America"
    },
    {
        "countryCode": "QA",
        "countryName": "Qatar",
        "currencyCode": "QAR",
        "population": "840926",
        "capital": "Doha",
        "continentName": "Asia"
    },
    {
        "countryCode": "RE",
        "countryName": "R\xe9union",
        "currencyCode": "EUR",
        "population": "776948",
        "capital": "Saint-Denis",
        "continentName": "Africa"
    },
    {
        "countryCode": "RO",
        "countryName": "Romania",
        "currencyCode": "RON",
        "population": "21959278",
        "capital": "Bucharest",
        "continentName": "Europe"
    },
    {
        "countryCode": "RS",
        "countryName": "Serbia",
        "currencyCode": "RSD",
        "population": "7344847",
        "capital": "Belgrade",
        "continentName": "Europe"
    },
    {
        "countryCode": "RU",
        "countryName": "Russia",
        "currencyCode": "RUB",
        "population": "140702000",
        "capital": "Moscow",
        "continentName": "Europe"
    },
    {
        "countryCode": "RW",
        "countryName": "Rwanda",
        "currencyCode": "RWF",
        "population": "11055976",
        "capital": "Kigali",
        "continentName": "Africa"
    },
    {
        "countryCode": "SA",
        "countryName": "Saudi Arabia",
        "currencyCode": "SAR",
        "population": "25731776",
        "capital": "Riyadh",
        "continentName": "Asia"
    },
    {
        "countryCode": "SB",
        "countryName": "Solomon Islands",
        "currencyCode": "SBD",
        "population": "559198",
        "capital": "Honiara",
        "continentName": "Oceania"
    },
    {
        "countryCode": "SC",
        "countryName": "Seychelles",
        "currencyCode": "SCR",
        "population": "88340",
        "capital": "Victoria",
        "continentName": "Africa"
    },
    {
        "countryCode": "SD",
        "countryName": "Sudan",
        "currencyCode": "SDG",
        "population": "35000000",
        "capital": "Khartoum",
        "continentName": "Africa"
    },
    {
        "countryCode": "SE",
        "countryName": "Sweden",
        "currencyCode": "SEK",
        "population": "9828655",
        "capital": "Stockholm",
        "continentName": "Europe"
    },
    {
        "countryCode": "SG",
        "countryName": "Singapore",
        "currencyCode": "SGD",
        "population": "4701069",
        "capital": "Singapore",
        "continentName": "Asia"
    },
    {
        "countryCode": "SH",
        "countryName": "Saint Helena",
        "currencyCode": "SHP",
        "population": "7460",
        "capital": "Jamestown",
        "continentName": "Africa"
    },
    {
        "countryCode": "SI",
        "countryName": "Slovenia",
        "currencyCode": "EUR",
        "population": "2007000",
        "capital": "Ljubljana",
        "continentName": "Europe"
    },
    {
        "countryCode": "SJ",
        "countryName": "Svalbard and Jan Mayen",
        "currencyCode": "NOK",
        "population": "2550",
        "capital": "Longyearbyen",
        "continentName": "Europe"
    },
    {
        "countryCode": "SK",
        "countryName": "Slovakia",
        "currencyCode": "EUR",
        "population": "5455000",
        "capital": "Bratislava",
        "continentName": "Europe"
    },
    {
        "countryCode": "SL",
        "countryName": "Sierra Leone",
        "currencyCode": "SLL",
        "population": "5245695",
        "capital": "Freetown",
        "continentName": "Africa"
    },
    {
        "countryCode": "SM",
        "countryName": "San Marino",
        "currencyCode": "EUR",
        "population": "31477",
        "capital": "San Marino",
        "continentName": "Europe"
    },
    {
        "countryCode": "SN",
        "countryName": "Senegal",
        "currencyCode": "XOF",
        "population": "12323252",
        "capital": "Dakar",
        "continentName": "Africa"
    },
    {
        "countryCode": "SO",
        "countryName": "Somalia",
        "currencyCode": "SOS",
        "population": "10112453",
        "capital": "Mogadishu",
        "continentName": "Africa"
    },
    {
        "countryCode": "SR",
        "countryName": "Suriname",
        "currencyCode": "SRD",
        "population": "492829",
        "capital": "Paramaribo",
        "continentName": "South America"
    },
    {
        "countryCode": "SS",
        "countryName": "South Sudan",
        "currencyCode": "SSP",
        "population": "8260490",
        "capital": "Juba",
        "continentName": "Africa"
    },
    {
        "countryCode": "ST",
        "countryName": "S\xe3o Tom\xe9 and Pr\xedncipe",
        "currencyCode": "STD",
        "population": "175808",
        "capital": "S\xe3o Tom\xe9",
        "continentName": "Africa"
    },
    {
        "countryCode": "SV",
        "countryName": "El Salvador",
        "currencyCode": "USD",
        "population": "6052064",
        "capital": "San Salvador",
        "continentName": "North America"
    },
    {
        "countryCode": "SX",
        "countryName": "Sint Maarten",
        "currencyCode": "ANG",
        "population": "37429",
        "capital": "Philipsburg",
        "continentName": "North America"
    },
    {
        "countryCode": "SY",
        "countryName": "Syria",
        "currencyCode": "SYP",
        "population": "22198110",
        "capital": "Damascus",
        "continentName": "Asia"
    },
    {
        "countryCode": "SZ",
        "countryName": "Swaziland",
        "currencyCode": "SZL",
        "population": "1354051",
        "capital": "Mbabane",
        "continentName": "Africa"
    },
    {
        "countryCode": "TC",
        "countryName": "Turks and Caicos Islands",
        "currencyCode": "USD",
        "population": "20556",
        "capital": "Cockburn Town",
        "continentName": "North America"
    },
    {
        "countryCode": "TD",
        "countryName": "Chad",
        "currencyCode": "XAF",
        "population": "10543464",
        "capital": "N'Djamena",
        "continentName": "Africa"
    },
    {
        "countryCode": "TF",
        "countryName": "French Southern Territories",
        "currencyCode": "EUR",
        "population": "140",
        "capital": "Port-aux-Fran\xe7ais",
        "continentName": "Antarctica"
    },
    {
        "countryCode": "TG",
        "countryName": "Togo",
        "currencyCode": "XOF",
        "population": "6587239",
        "capital": "Lom\xe9",
        "continentName": "Africa"
    },
    {
        "countryCode": "TH",
        "countryName": "Thailand",
        "currencyCode": "THB",
        "population": "67089500",
        "capital": "Bangkok",
        "continentName": "Asia"
    },
    {
        "countryCode": "TJ",
        "countryName": "Tajikistan",
        "currencyCode": "TJS",
        "population": "7487489",
        "capital": "Dushanbe",
        "continentName": "Asia"
    },
    {
        "countryCode": "TK",
        "countryName": "Tokelau",
        "currencyCode": "NZD",
        "population": "1466",
        "capital": "",
        "continentName": "Oceania"
    },
    {
        "countryCode": "TL",
        "countryName": "East Timor",
        "currencyCode": "USD",
        "population": "1154625",
        "capital": "Dili",
        "continentName": "Oceania"
    },
    {
        "countryCode": "TM",
        "countryName": "Turkmenistan",
        "currencyCode": "TMT",
        "population": "4940916",
        "capital": "Ashgabat",
        "continentName": "Asia"
    },
    {
        "countryCode": "TN",
        "countryName": "Tunisia",
        "currencyCode": "TND",
        "population": "10589025",
        "capital": "Tunis",
        "continentName": "Africa"
    },
    {
        "countryCode": "TO",
        "countryName": "Tonga",
        "currencyCode": "TOP",
        "population": "122580",
        "capital": "Nuku'alofa",
        "continentName": "Oceania"
    },
    {
        "countryCode": "TR",
        "countryName": "Turkey",
        "currencyCode": "TRY",
        "population": "77804122",
        "capital": "Ankara",
        "continentName": "Asia"
    },
    {
        "countryCode": "TT",
        "countryName": "Trinidad and Tobago",
        "currencyCode": "TTD",
        "population": "1228691",
        "capital": "Port of Spain",
        "continentName": "North America"
    },
    {
        "countryCode": "TV",
        "countryName": "Tuvalu",
        "currencyCode": "AUD",
        "population": "10472",
        "capital": "Funafuti",
        "continentName": "Oceania"
    },
    {
        "countryCode": "TW",
        "countryName": "Taiwan",
        "currencyCode": "TWD",
        "population": "22894384",
        "capital": "Taipei",
        "continentName": "Asia"
    },
    {
        "countryCode": "TZ",
        "countryName": "Tanzania",
        "currencyCode": "TZS",
        "population": "41892895",
        "capital": "Dodoma",
        "continentName": "Africa"
    },
    {
        "countryCode": "UA",
        "countryName": "Ukraine",
        "currencyCode": "UAH",
        "population": "45415596",
        "capital": "Kiev",
        "continentName": "Europe"
    },
    {
        "countryCode": "UG",
        "countryName": "Uganda",
        "currencyCode": "UGX",
        "population": "33398682",
        "capital": "Kampala",
        "continentName": "Africa"
    },
    {
        "countryCode": "UM",
        "countryName": "U.S. Minor Outlying Islands",
        "currencyCode": "USD",
        "population": "0",
        "capital": "",
        "continentName": "Oceania"
    },
    {
        "countryCode": "US",
        "countryName": "United States",
        "currencyCode": "USD",
        "population": "310232863",
        "capital": "Washington",
        "continentName": "North America"
    },
    {
        "countryCode": "UY",
        "countryName": "Uruguay",
        "currencyCode": "UYU",
        "population": "3477000",
        "capital": "Montevideo",
        "continentName": "South America"
    },
    {
        "countryCode": "UZ",
        "countryName": "Uzbekistan",
        "currencyCode": "UZS",
        "population": "27865738",
        "capital": "Tashkent",
        "continentName": "Asia"
    },
    {
        "countryCode": "VA",
        "countryName": "Vatican City",
        "currencyCode": "EUR",
        "population": "921",
        "capital": "Vatican City",
        "continentName": "Europe"
    },
    {
        "countryCode": "VC",
        "countryName": "Saint Vincent and the Grenadines",
        "currencyCode": "XCD",
        "population": "104217",
        "capital": "Kingstown",
        "continentName": "North America"
    },
    {
        "countryCode": "VE",
        "countryName": "Venezuela",
        "currencyCode": "VEF",
        "population": "27223228",
        "capital": "Caracas",
        "continentName": "South America"
    },
    {
        "countryCode": "VG",
        "countryName": "British Virgin Islands",
        "currencyCode": "USD",
        "population": "21730",
        "capital": "Road Town",
        "continentName": "North America"
    },
    {
        "countryCode": "VI",
        "countryName": "U.S. Virgin Islands",
        "currencyCode": "USD",
        "population": "108708",
        "capital": "Charlotte Amalie",
        "continentName": "North America"
    },
    {
        "countryCode": "VN",
        "countryName": "Vietnam",
        "currencyCode": "VND",
        "population": "89571130",
        "capital": "Hanoi",
        "continentName": "Asia"
    },
    {
        "countryCode": "VU",
        "countryName": "Vanuatu",
        "currencyCode": "VUV",
        "population": "221552",
        "capital": "Port Vila",
        "continentName": "Oceania"
    },
    {
        "countryCode": "WF",
        "countryName": "Wallis and Futuna",
        "currencyCode": "XPF",
        "population": "16025",
        "capital": "Mata-Utu",
        "continentName": "Oceania"
    },
    {
        "countryCode": "WS",
        "countryName": "Samoa",
        "currencyCode": "WST",
        "population": "192001",
        "capital": "Apia",
        "continentName": "Oceania"
    },
    {
        "countryCode": "XK",
        "countryName": "Kosovo",
        "currencyCode": "EUR",
        "population": "1800000",
        "capital": "Pristina",
        "continentName": "Europe"
    },
    {
        "countryCode": "YE",
        "countryName": "Yemen",
        "currencyCode": "YER",
        "population": "23495361",
        "capital": "Sanaa",
        "continentName": "Asia"
    },
    {
        "countryCode": "YT",
        "countryName": "Mayotte",
        "currencyCode": "EUR",
        "population": "159042",
        "capital": "Mamoudzou",
        "continentName": "Africa"
    },
    {
        "countryCode": "ZA",
        "countryName": "South Africa",
        "currencyCode": "ZAR",
        "population": "49000000",
        "capital": "Pretoria",
        "continentName": "Africa"
    },
    {
        "countryCode": "ZM",
        "countryName": "Zambia",
        "currencyCode": "ZMW",
        "population": "13460305",
        "capital": "Lusaka",
        "continentName": "Africa"
    },
    {
        "countryCode": "ZW",
        "countryName": "Zimbabwe",
        "currencyCode": "ZWL",
        "population": "13061000",
        "capital": "Harare",
        "continentName": "Africa"
    }
];


/***/ })

};
;